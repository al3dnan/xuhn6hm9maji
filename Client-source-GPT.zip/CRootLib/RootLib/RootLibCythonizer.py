from sys import path as sys_path
from os.path import splitext as op_splitext
import os
import shutil

libpath = r'..\Py2Lib\lib'
sys_path.append(libpath)
rootpath = r'.'

capNameList = {
	"colorinfo":"colorInfo",
	"consolemodule":"consoleModule",
	"constinfo":"constInfo",
	"debuginfo":"debugInfo",
	"dragon_soul_refine_settings":"dragon_soul_refine_settings",
	"emotion":"emotion",
	"exception":"exception",
	"game":"game",
	"interfacemodule":"interfaceModule",
	"introcreate":"introCreate",
	"introempire":"introEmpire",
	"introloading":"introLoading",
	"intrologin":"introLogin",
	"intrologo":"introLogo",
	"introselect":"introSelect",
	"localeinfo":"localeInfo",
	"mousemodule":"mouseModule",
	"musicinfo":"musicInfo",
	"networkmodule":"networkModule",
	"playersettingmodule":"playerSettingModule",
	"prototype":"Prototype",
	"rootlibcythonizer":"RootLibCythonizer",
	"servercommandparser":"serverCommandParser",
	"serverinfo":"serverInfo",
	"stringcommander":"stringCommander",
	"system":"system",
	"test_affect":"test_affect",
	"ui":"ui",
	"uiaffectshower":"uiAffectShower",
	"uiattachmetin":"uiAttachMetin",
	"uiauction":"uiAuction",
	"uiautoban":"uiAutoban",
	"uicandidate":"uiCandidate",
	"uicharacter":"uiCharacter",
	"uichat":"uiChat",
	"uicommon":"uiCommon",
	"uicube":"uiCube",
	"uidragonsoul":"uiDragonSoul",
	"uiequipmentdialog":"uiEquipmentDialog",
	"uiex":"uiEx",
	"uiexchange":"uiExchange",
	"uigamebutton":"uiGameButton",
	"uigameoption":"uiGameOption",
	"uiguild":"uiGuild",
	"uihelp":"uiHelp",
	"uiinventory":"uiInventory",
	"uimapnameshower":"uiMapNameShower",
	"uimessenger":"uiMessenger",
	"uiminimap":"uiMiniMap",
	"uioption":"uiOption",
	"uiparty":"uiParty",
	"uiphasecurtain":"uiPhaseCurtain",
	"uipickmoney":"uiPickMoney",
	"uiplayergauge":"uiPlayerGauge",
	"uipointreset":"uiPointReset",
	"uiprivateshopbuilder":"uiPrivateShopBuilder",
	"uiquest":"uiQuest",
	"uirefine":"uiRefine",
	"uirestart":"uiRestart",
	"uisafebox":"uiSafebox",
	"uiscriptlocale":"uiScriptLocale",
	"uiselectitem":"uiselectitem", #
	"uiselectmusic":"uiSelectMusic",
	"uishop":"uiShop",
	"uisystem":"uiSystem",
	"uisystemoption":"uiSystemOption",
	"uitarget":"uiTarget",
	"uitaskbar":"uiTaskBar",
	"uitip":"uiTip",
	"uitooltip":"uiToolTip",
	"uiuploadmark":"uiUploadMark",
	"uiweb":"uiWeb",
	"uiwhisper":"uiWhisper",
	"utils":"utils",
}

def checkCapName(x):
    base, ext = op_splitext(x)
    try:
        return capNameList[base.lower()] + ext
    except KeyError:
        return x

# Import utils
import imp
fp, pathname, description = imp.find_module('utils', [libpath])
utils = imp.load_module('utils', fp, pathname, description)

# Find .py files in the rootpath
pys = utils.findMatchedFiles(rootpath, "*.py")
if __file__ in pys:
    pys.remove(__file__)
pys = [checkCapName(x) for x in pys]

# Import cythonizer
import cythonizer
moduleLst = cythonizer.run(pys, forceRecompile=True)
moduleNameLst = []
sourceFileLst = []

for m in moduleLst:
    for source in m.sources:
        base, ext = op_splitext(source)
        moduleName = base.split('/')[-1]
        moduleNameLst.append(moduleName)
        sourceFileLst.append(base + (".cpp" if "c++" == m.language else ".c"))

# Import sourceWriter
import sourceWriter
sourceFileName = sourceWriter.run(moduleNameLst, 'rootlib')

# Modify "PythonrootlibManager.cpp" after successfully creating all
if sourceFileName:
    cpp_file_path = os.path.join(rootpath, 'PythonrootlibManager.cpp')
    h_file_path = os.path.join(rootpath, 'PythonrootlibManager.h')
    if os.path.isfile(cpp_file_path) and os.path.isfile(h_file_path):
        with open(cpp_file_path, 'r') as cpp_file:
            cpp_lines = cpp_file.readlines()
        cpp_lines[0:7] = [
            '#include "StdAfx.h"\n',
            '#include "PythonrootlibManager.h"\n',
            '#include "../../Extern/Python2/Python.h"\n',
            '#ifdef _DEBUG\n',
            '#pragma comment (lib, "rootlib_d.lib")\n',
            '#else\n',
            '#pragma comment (lib, "rootlib.lib")\n',
            '#endif',
        ]
        with open(cpp_file_path, 'w') as cpp_file:
            cpp_file.writelines(cpp_lines)

        # Move the files to the target directory and replace existing files
        target_dir = os.path.join(os.path.expanduser('~'), 'Desktop', 'Skypia-3', '(VMWARE - SERVER)', 'Client Source', 'Client', 'UserInterface')
        shutil.move(cpp_file_path, os.path.join(target_dir, 'PythonrootlibManager.cpp'))
        shutil.move(h_file_path, os.path.join(target_dir, 'PythonrootlibManager.h'))

    print("%s successfully created and moved." % sourceFileName)
else:
    print("No source file created.")