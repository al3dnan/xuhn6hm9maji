import item
import localeInfo
addonItemList = {
	180,
	190,
	290,
	1130,
	1170,
	2150,
	2170,
	3160,
	3210,
	5110,
	5120,
	7160
}
bonusNameList = {
	1: localeInfo.ENCHANT_SYSTEM_BONUS_1,
	2: localeInfo.ENCHANT_SYSTEM_BONUS_2,
	3: localeInfo.ENCHANT_SYSTEM_BONUS_3,
	4: localeInfo.ENCHANT_SYSTEM_BONUS_4,
	5: localeInfo.ENCHANT_SYSTEM_BONUS_5,
	6: localeInfo.ENCHANT_SYSTEM_BONUS_6,
	7: localeInfo.ENCHANT_SYSTEM_BONUS_7,
	8: localeInfo.ENCHANT_SYSTEM_BONUS_8,
	9: localeInfo.ENCHANT_SYSTEM_BONUS_9,
	10: localeInfo.ENCHANT_SYSTEM_BONUS_10,
	11: localeInfo.ENCHANT_SYSTEM_BONUS_11,
	12: localeInfo.ENCHANT_SYSTEM_BONUS_12,
	#13: localeInfo.ENCHANT_SYSTEM_BONUS_13,
	14: localeInfo.ENCHANT_SYSTEM_BONUS_14,
	15: localeInfo.ENCHANT_SYSTEM_BONUS_15,
	16: localeInfo.ENCHANT_SYSTEM_BONUS_16,
	17: localeInfo.ENCHANT_SYSTEM_BONUS_17,
	#18: localeInfo.ENCHANT_SYSTEM_BONUS_18,
	#19: localeInfo.ENCHANT_SYSTEM_BONUS_19,
	#20: localeInfo.ENCHANT_SYSTEM_BONUS_20,
	#21: localeInfo.ENCHANT_SYSTEM_BONUS_21,
	#22: localeInfo.ENCHANT_SYSTEM_BONUS_22,
	23: localeInfo.ENCHANT_SYSTEM_BONUS_23,
	24: localeInfo.ENCHANT_SYSTEM_BONUS_24,
	#25: localeInfo.ENCHANT_SYSTEM_BONUS_25,
	27: localeInfo.ENCHANT_SYSTEM_BONUS_26,
	28: localeInfo.ENCHANT_SYSTEM_BONUS_27,
	29: localeInfo.ENCHANT_SYSTEM_BONUS_28,
	30: localeInfo.ENCHANT_SYSTEM_BONUS_29,
	31: localeInfo.ENCHANT_SYSTEM_BONUS_30,
	32: localeInfo.ENCHANT_SYSTEM_BONUS_31,
	33: localeInfo.ENCHANT_SYSTEM_BONUS_32,
	34: localeInfo.ENCHANT_SYSTEM_BONUS_33,
	37: localeInfo.ENCHANT_SYSTEM_BONUS_34,
	39: localeInfo.ENCHANT_SYSTEM_BONUS_35,
	41: localeInfo.ENCHANT_SYSTEM_BONUS_36,
	#43: localeInfo.ENCHANT_SYSTEM_BONUS_37,
	#44: localeInfo.ENCHANT_SYSTEM_BONUS_38,
	#45: localeInfo.ENCHANT_SYSTEM_BONUS_39,
	48: localeInfo.ENCHANT_SYSTEM_BONUS_40,
	49: localeInfo.ENCHANT_SYSTEM_BONUS_41,
	53: localeInfo.ENCHANT_SYSTEM_BONUS_42,
	#86: localeInfo.ENCHANT_SYSTEM_BONUS_43,
	#97: localeInfo.ENCHANT_SYSTEM_BONUS_44,
	#98: localeInfo.ENCHANT_SYSTEM_BONUS_45,
	#99: localeInfo.ENCHANT_SYSTEM_BONUS_46,
	#100: localeInfo.ENCHANT_SYSTEM_BONUS_47,
	#101: localeInfo.ENCHANT_SYSTEM_BONUS_48,
	#102: localeInfo.ENCHANT_SYSTEM_BONUS_49,
	#103: localeInfo.ENCHANT_SYSTEM_BONUS_50,
}
mainBonusTableList = [
	#ARMOR_BODY
	[1,9,23,24,29,30,31,32,33,34,39,53],
	#ARMOR_HEAD
	[7,10,11,12,17,18,19,20,21,22,24,28,37],
	#ARMOR_SHIELD
	[3,4,5,6,17,18,19,20,21,22,27,39,43,44,48,49],
	#ARMOR_WRIST
	[1,2,16,17,18,19,20,21,22,23,25,37],
	#ARMOR_FOOTS
	[1,2,7,14,15,28,29,30,31,32,33,34,43,44],
	#ARMOR_NECK
	[1,2,10,11,15,16,24,29,30,31,32,33,34,43,44],
	#ARMOR_EAR
	[8,17,18,19,20,21,22,25,29,30,31,32,33,34,41],
	#ITEM_TYPE_WEAPON
	[3,4,5,6,9,12,14,15,16,17,18,19,20,21,22],
	#else
	#[86,97,98,99,100,101,102,103]
]

def GetFitBonusList(itemType, itemSubType):
	global mainBonusTableList
	if item.ITEM_TYPE_WEAPON == itemType:
		return mainBonusTableList[7]
	elif item.ARMOR_BODY == itemSubType:
		return mainBonusTableList[0]
	elif item.ARMOR_HEAD == itemSubType:
		return mainBonusTableList[1]
	elif item.ARMOR_SHIELD == itemSubType:
		return mainBonusTableList[2]
	elif item.ARMOR_WRIST == itemSubType:
		return mainBonusTableList[3]
	elif item.ARMOR_FOOTS == itemSubType:
		return mainBonusTableList[4]
	elif item.ARMOR_NECK == itemSubType:
		return mainBonusTableList[5]
	elif item.ARMOR_EAR == itemSubType:
		return mainBonusTableList[6]
	
	#elif item.ARMOR_PENDANT == itemSubType:
	#	return mainBonusTableList[8]
	import exception
	exception.Abort('GetBonusListWithSubType.NoData')