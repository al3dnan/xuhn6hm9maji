#####################################################
#				Code by Deloxone					#
#		   											#
#		 Danke Retro F?f??r Den Grunde Code			#
#		   											#
#			    12.September.2018					#
#####################################################

import pythonEncode
net = __import__(pythonEncode.GetModuleName("net"))
import snd
import localeInfo
import ui
import uitooltip
import dbg
import os
import background
import constInfo
app = __import__(pythonEncode.GetModuleName("app"))

class SkyboxChanger(ui.BoardWithTitleBar):
	def __init__(self):
		ui.BoardWithTitleBar.__init__(self)
		self.LoadSkyboxChanger()
		
	def __del__(self):
		ui.BoardWithTitleBar.__del__(self)
		
	def Destroy(self):
		self.Hide()
		return TRUE
		
	def LoadSkyboxChanger(self):
		self.SetSize(128, 350)
		self.Hide()
		self.AddFlag('movable')
		self.AddFlag("float")
		self.SetTitleName(localeInfo.WEATHERNAME)
		self.SetCenterPosition()
		self.SetCloseEvent(self.Close)
				
		self.LoadButtons()
		
	def LoadButtons(self):
			
		self.W1Button = ui.Button()
		self.W1Button.SetParent(self)
		self.W1Button.SetPosition(20, 40)
		self.W1Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W1Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W1Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W1Button.SetText(localeInfo.WEATHER1)
		self.W1Button.SetEvent(self.wetter1)
		self.W1Button.Show()
		
		self.W2Button = ui.Button()
		self.W2Button.SetParent(self)
		self.W2Button.SetPosition(20, 70)
		self.W2Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W2Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W2Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W2Button.SetText(localeInfo.WEATHER2)
		self.W2Button.SetEvent(self.wetter2)
		self.W2Button.Show()
		
		self.W3Button = ui.Button()
		self.W3Button.SetParent(self)
		self.W3Button.SetPosition(20, 100)
		self.W3Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W3Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W3Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W3Button.SetText(localeInfo.WEATHER3)
		self.W3Button.SetEvent(self.wetter3)
		self.W3Button.Show()
		
		self.W4Button = ui.Button()
		self.W4Button.SetParent(self)
		self.W4Button.SetPosition(20, 130)
		self.W4Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W4Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W4Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W4Button.SetText(localeInfo.WEATHER4)
		self.W4Button.SetEvent(self.wetter4)
		self.W4Button.Show()
		
		self.W5Button = ui.Button()
		self.W5Button.SetParent(self)
		self.W5Button.SetPosition (20, 160)
		self.W5Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W5Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W5Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W5Button.SetText(localeInfo.WEATHER5)
		self.W5Button.SetEvent(self.wetter5)
		self.W5Button.Show()
		
		self.W6Button = ui.Button()
		self.W6Button.SetParent(self)
		self.W6Button.SetPosition(20, 190)
		self.W6Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W6Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W6Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W6Button.SetText(localeInfo.WEATHER6)
		self.W6Button.SetEvent(self.wetter6)
		self.W6Button.Show()
		
		self.W7Button = ui.Button()
		self.W7Button.SetParent(self)
		self.W7Button.SetPosition(20, 220)
		self.W7Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W7Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W7Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W7Button.SetText(localeInfo.WEATHER7)
		self.W7Button.SetEvent(self.wetter7)
		self.W7Button.Show()
		
		self.W8Button = ui.Button()
		self.W8Button.SetParent(self)
		self.W8Button.SetPosition(20, 250)
		self.W8Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W8Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W8Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W8Button.SetText(localeInfo.WEATHER8)
		self.W8Button.SetEvent(self.wetter8)
		self.W8Button.Show()
		
		self.W9Button = ui.Button()
		self.W9Button.SetParent(self)
		self.W9Button.SetPosition(20, 280)
		self.W9Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W9Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W9Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W9Button.SetText(localeInfo.WEATHER9)
		self.W9Button.SetEvent(self.wetter9)
		self.W9Button.Show()
		
		self.W10Button = ui.Button()
		self.W10Button.SetParent(self)
		self.W10Button.SetPosition(20, 310)
		self.W10Button.SetUpVisual("d:/ymir work/ui/public/Large_Button_01.sub")
		self.W10Button.SetOverVisual("d:/ymir work/ui/public/Large_Button_02.sub")
		self.W10Button.SetDownVisual("d:/ymir work/ui/public/Large_Button_03.sub")
		self.W10Button.SetText(localeInfo.WEATHER10)
		self.W10Button.SetEvent(self.wetter10)
		self.W10Button.Show()
				
	def wetter1(self):	
		background.RegisterEnvironmentData(1, "d:/ymir work/environment/Deloxone/cloudymonth/cloudymonth_kf.msenv")  
		background.SetEnvironmentData(1)	
		
	def wetter2(self):	
		background.RegisterEnvironmentData(2, "d:/ymir work/environment/Deloxone/cloudysun/cloudysun_kf.msenv")  
		background.SetEnvironmentData(2)		
		
	def wetter3(self):	
		background.RegisterEnvironmentData(3, "d:/ymir work/environment/Deloxone/eveningsun/eveningsun_kf.msenv")  
		background.SetEnvironmentData(3)	

	def wetter4(self):	
		background.RegisterEnvironmentData(4, "d:/ymir work/environment/Deloxone/foggysunset/foggysunset_kf.msenv")  
		background.SetEnvironmentData(4)	

	def wetter5(self):	
		background.RegisterEnvironmentData(5, "d:/ymir work/environment/Deloxone/hazysun/hazysun_kf.msenv")  
		background.SetEnvironmentData(5)	

	def wetter6(self):	
		background.RegisterEnvironmentData(6, "d:/ymir work/environment/Deloxone/overcastday/overcastday_kf.msenv")  
		background.SetEnvironmentData(6)

	def wetter7(self):	
		background.RegisterEnvironmentData(7, "d:/ymir work/environment/Deloxone/rainyday/rainyday_kf.msenv")  
		background.SetEnvironmentData(7)
		
	def wetter8(self):	
		background.RegisterEnvironmentData(8, "d:/ymir work/environment/Deloxone/summersun/summersun_kf.msenv")  
		background.SetEnvironmentData(8)

	def wetter9(self):	
		background.RegisterEnvironmentData(9, "d:/ymir work/environment/Deloxone/sunhorizon/sunhorizon_kf.msenv")  
		background.SetEnvironmentData(9)
		
	def wetter10(self):	
		background.RegisterEnvironmentData(10, "d:/ymir work/environment/Deloxone/sunset/sunset_kf.msenv")  
		background.SetEnvironmentData(10)	

	def wetter11(self):	
		background.SetEnvironmentData(0)

	def wetter12(self):	
		background.RegisterEnvironmentData(12, constInfo.ENVIRONMENT_NIGHT)  
		background.SetEnvironmentData(12)			
				
	def Close(self):
		self.Hide()

	def OnPressEscapeKey(self):
		self.Close()
		return TRUE
		
