import pythonEncode
import ui
import uiScriptLocale
net = __import__(pythonEncode.GetModuleName("net"))
app = __import__(pythonEncode.GetModuleName("app"))
import dbg
player = __import__(pythonEncode.GetModuleName("player"))
import background
import wndMgr
import localeInfo
chrmgr = __import__(pythonEncode.GetModuleName("chrmgr"))
import colorInfo
import constInfo
import playersettingmodule
import stringCommander
import emotion
import uiRefine
import uiToolTip
import uiAttachMetin
import uiPickMoney
import uiChat
import uiMessenger
import uiHelp
import uiWhisper
import uiPointReset
import uiShop
import uiExchange
import uiSystem
import uiOption
import uiRestart
from _weakref import proxy
NAME_COLOR_DICT = {
	chrmgr.NAMECOLOR_PC : colorInfo.CHR_NAME_RGB_PC,
	chrmgr.NAMECOLOR_NPC : colorInfo.CHR_NAME_RGB_NPC,
	chrmgr.NAMECOLOR_MOB : colorInfo.CHR_NAME_RGB_MOB,
	chrmgr.NAMECOLOR_PVP : colorInfo.CHR_NAME_RGB_PVP,
	chrmgr.NAMECOLOR_PK : colorInfo.CHR_NAME_RGB_PK,
	chrmgr.NAMECOLOR_PARTY : colorInfo.CHR_NAME_RGB_PARTY,
	chrmgr.NAMECOLOR_WARP : colorInfo.CHR_NAME_RGB_WARP,
	chrmgr.NAMECOLOR_WAYPOINT : colorInfo.CHR_NAME_RGB_WAYPOINT,
	chrmgr.NAMECOLOR_EMPIRE_MOB : colorInfo.CHR_NAME_RGB_EMPIRE_MOB,
	chrmgr.NAMECOLOR_EMPIRE_NPC : colorInfo.CHR_NAME_RGB_EMPIRE_NPC,
	chrmgr.NAMECOLOR_EMPIRE_PC+1 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_A,
	chrmgr.NAMECOLOR_EMPIRE_PC+2 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_B,
	chrmgr.NAMECOLOR_EMPIRE_PC+3 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_C,
}
TITLE_COLOR_LIST = (
	colorInfo.TITLE_RGB_GOOD_4,
	colorInfo.TITLE_RGB_GOOD_3,
	colorInfo.TITLE_RGB_GOOD_2,
	colorInfo.TITLE_RGB_GOOD_1,
	colorInfo.TITLE_RGB_NORMAL,
	colorInfo.TITLE_RGB_EVIL_1,
	colorInfo.TITLE_RGB_EVIL_2,
	colorInfo.TITLE_RGB_EVIL_3,
	colorInfo.TITLE_RGB_EVIL_4,	
)
def __main__():
	if app.TOURNAMENT_PVP_SYSTEM:
		NAME_COLOR_DICT.update({chrmgr.NAMECOLOR_TOURNAMENT_TEAM_A : (255, 31, 31),})
		NAME_COLOR_DICT.update({chrmgr.NAMECOLOR_TOURNAMENT_TEAM_B : (10, 135, 245),})
	for nameIndex, nameColor in NAME_COLOR_DICT.items():
		chrmgr.RegisterNameColor(nameIndex, *nameColor)
	for titleIndex, titleColor in enumerate(TITLE_COLOR_LIST):
		chrmgr.RegisterTitleColor(titleIndex, *titleColor)
	for titleIndex, titleName in enumerate(localeInfo.TITLE_NAME_LIST):
		chrmgr.RegisterTitleName(titleIndex, titleName)
	emotion.RegisterEmotionIcons()
	dungeonMapNameList = ("metin2_map_spiderdungeon", "metin2_map_monkeydungeon", "metin2_map_monkeydungeon_02", "metin2_map_monkeydungeon_03", "metin2_map_deviltower1")
	for dungeonMapName in dungeonMapNameList:
		background.RegisterDungeonMapName(dungeonMapName)
	playersettingmodule.LoadGuildBuildingList(localeInfo.GUILD_BUILDING_LIST_TXT)
class LoadingWindow(ui.ScriptWindow):
	def __init__(self, stream):
		ui.Window.__init__(self)
		net.SetPhaseWindow(net.PHASE_WINDOW_LOAD, self)
		self.stream = proxy(stream)
		self.loadingImages = None
		self.errMsg=0
		self.playerX = 0
		self.playerY = 0
	def Open(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/LoadingWindow.py")
		except:
			import exception
			exception.Abort("LodingWindow.Open - LoadScriptFile Error")
		try:
			self.errMsg=self.GetChild("ErrorMessage")
		except:
			import exception
			exception.Abort("LodingWindow.Open - LoadScriptFile Error")
		self.errMsg.Hide()
		self.Show()
		chrSlot=self.stream.GetCharacterSlot()
		net.SendSelectCharacterPacket(chrSlot)
		app.SetFrameSkip(0)
	def Close(self):
		self.loadingImages = None
		self.errMsg=0
		self.ClearDictionary()
		self.Hide()
	def OnPressEscapeKey(self):
		app.SetFrameSkip(1)
		self.stream.SetLoginPhase()
		return True
	def DEBUG_LoadData(self, playerX, playerY):
		self.playerX = playerX
		self.playerY = playerY
		self.LoadData(playerX, playerY)
	def __InitData(self):
		playersettingmodule.LoadGameData("INIT")
	def __RegisterDungeonMapName(self):
		background.RegisterDungeonMapName("metin2_map_spiderdungeon")
		background.RegisterDungeonMapName("metin2_map_monkeydungeon")
		background.RegisterDungeonMapName("metin2_map_monkeydungeon_02")
		background.RegisterDungeonMapName("metin2_map_monkeydungeon_03")
		background.RegisterDungeonMapName("metin2_map_deviltower1")
	def __RegisterSkill(self):
		race = net.GetMainActorRace()
		group = net.GetMainActorSkillGroup()
		empire = net.GetMainActorEmpire()
		playersettingmodule.RegisterSkill(race, group, empire)
	def __RegisterTitleName(self):
		for i in xrange(len(localeInfo.TITLE_NAME_LIST)):
			chrmgr.RegisterTitleName(i, localeInfo.TITLE_NAME_LIST[i])
	def __RegisterColor(self):
		NAME_COLOR_DICT = {
			chrmgr.NAMECOLOR_PC : colorInfo.CHR_NAME_RGB_PC,
			chrmgr.NAMECOLOR_NPC : colorInfo.CHR_NAME_RGB_NPC,
			chrmgr.NAMECOLOR_MOB : colorInfo.CHR_NAME_RGB_MOB,
			chrmgr.NAMECOLOR_PVP : colorInfo.CHR_NAME_RGB_PVP,
			chrmgr.NAMECOLOR_PK : colorInfo.CHR_NAME_RGB_PK,
			chrmgr.NAMECOLOR_PARTY : colorInfo.CHR_NAME_RGB_PARTY,
			chrmgr.NAMECOLOR_WARP : colorInfo.CHR_NAME_RGB_WARP,
			chrmgr.NAMECOLOR_WAYPOINT : colorInfo.CHR_NAME_RGB_WAYPOINT,
			chrmgr.NAMECOLOR_EMPIRE_MOB : colorInfo.CHR_NAME_RGB_EMPIRE_MOB,
			chrmgr.NAMECOLOR_EMPIRE_NPC : colorInfo.CHR_NAME_RGB_EMPIRE_NPC,
			chrmgr.NAMECOLOR_EMPIRE_PC+1 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_A,
			chrmgr.NAMECOLOR_EMPIRE_PC+2 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_B,
			chrmgr.NAMECOLOR_EMPIRE_PC+3 : colorInfo.CHR_NAME_RGB_EMPIRE_PC_C,
		}
		for name, rgb in NAME_COLOR_DICT.items():
			chrmgr.RegisterNameColor(name, rgb[0], rgb[1], rgb[2])
		TITLE_COLOR_DICT = (	colorInfo.TITLE_RGB_GOOD_4,
								colorInfo.TITLE_RGB_GOOD_3,
								colorInfo.TITLE_RGB_GOOD_2,
								colorInfo.TITLE_RGB_GOOD_1,
								colorInfo.TITLE_RGB_NORMAL,
								colorInfo.TITLE_RGB_EVIL_1,
								colorInfo.TITLE_RGB_EVIL_2,
								colorInfo.TITLE_RGB_EVIL_3,
								colorInfo.TITLE_RGB_EVIL_4,	)
		count = 0
		for rgb in TITLE_COLOR_DICT:
			chrmgr.RegisterTitleColor(count, rgb[0], rgb[1], rgb[2])
			count += 1
	def __RegisterEmotionIcon(self):
		emotion.RegisterEmotionIcons()
	def __LoadMap(self):
		net.Warp(self.playerX, self.playerY)
	def __LoadSound(self):
		playersettingmodule.LoadGameData("SOUND")
	def __LoadEffect(self):
		playersettingmodule.LoadGameData("EFFECT")
	def __LoadWarrior(self):
		playersettingmodule.LoadGameData("WARRIOR")
	def __LoadAssassin(self):
		playersettingmodule.LoadGameData("ASSASSIN")
	def __LoadSura(self):
		playersettingmodule.LoadGameData("SURA")
	def __LoadShaman(self):
		playersettingmodule.LoadGameData("SHAMAN")
	if app.ENABLE_WOLFMAN_CHARACTER:
		def __LoadWolfman(self):
			playersettingmodule.LoadGameData("WOLFMAN")
	def __LoadSkill(self):
		playersettingmodule.LoadGameData("SKILL")
	def __LoadNPC(self):
		playersettingmodule.LoadGameData("NPC")
	def LoadData(self, playerX, playerY):
		self.playerX=playerX
		self.playerY=playerY
		self.__RegisterSkill()
		self.__RegisterTitleName()
		self.__RegisterColor()
		self.__InitData()
		self.__LoadMap()
		self.__LoadSound()
		self.__LoadEffect()
		self.__LoadWarrior()
		self.__LoadAssassin()
		self.__LoadSura()
		self.__LoadShaman()
		if app.ENABLE_WOLFMAN_CHARACTER:
			self.__LoadWolfman()
		self.__LoadSkill()
		self.__LoadNPC()
		playersettingmodule.RegisterSkill(net.GetMainActorRace(), net.GetMainActorSkillGroup(), net.GetMainActorEmpire())
		background.SetViewDistanceSet(background.DISTANCE0, 25600)
		background.SelectViewDistanceNum(background.DISTANCE0)
		app.SetGlobalCenterPosition(self.playerX, self.playerY)
		net.StartGame()