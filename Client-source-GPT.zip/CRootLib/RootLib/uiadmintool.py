import pythonEncode
net = __import__(pythonEncode.GetModuleName("net"))
import localeInfo
import ui
import uiGuild
import uiToolTip
import wndMgr
from _weakref import proxy
import constInfo

BAN_DESCRIPTION_TYPE = [
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_1,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_2,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_3,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_4,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_5,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_6,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_7,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_8,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_9,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_10,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_DESCRIPTION_11
]

DESCRIPTION_TYPE_BAN = [
	localeInfo.ADMIN_MANAGER_BAN_TYPE_1, 
	localeInfo.ADMIN_MANAGER_BAN_TYPE_2, 
	localeInfo.ADMIN_MANAGER_BAN_TYPE_3,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_4,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_5,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_6,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_7,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_8,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_9,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_10,
	localeInfo.ADMIN_MANAGER_BAN_TYPE_11
]

class CheckBox(ui.ImageBox):
	def __init__(self, parent, key, x, y, event, filename = "d:/ymir work/ui/public/Parameter_Slot_01.sub"):
		ui.ImageBox.__init__(self)
		self.SetParent(parent)
		self.SetPosition(x, y)
		
		self.txt = ui.TextLine()
		self.txt.SetParent(parent)
		self.txt.SetPosition(x + 5, y + 2)
		#self.txt.SetText(DESCRIPTION_TYPE_BAN[key])
		self.txt.Show()

		self.LoadImage(filename)
		self.mouse = uiGuild.MouseReflector(self)
		self.mouse.SetSize(self.GetWidth(), self.GetHeight())

		image = ui.MakeImageBox(self, "d:/ymir work/ui/public/check_image.sub", 0, - 1)
		image.AddFlag("not_pick")
		image.SetWindowHorizontalAlignCenter()
		image.SetWindowVerticalAlignCenter()
		image.Hide()
		self.Enable = TRUE
		self.image = image
		self.event = event
		self.Show()
		self.mouse.UpdateRect()

	def __del__(self):
		ui.ImageBox.__del__(self)

	def SetCheck(self, flag):
		if flag:
			self.image.Show()
		else:
			self.image.Hide()

	def Disable(self):
		self.Enable = FALSE
		
	def IsSelected(self):
		if self.image.IsShow():
			return True
		return False

	def OnMouseOverIn(self):
		if not self.Enable:
			return
		self.mouse.Show()

	def OnMouseOverOut(self):
		if not self.Enable:
			return
		self.mouse.Hide()

	def OnMouseLeftButtonDown(self):
		if not self.Enable:
			return
		self.mouse.Down()

	def OnMouseLeftButtonUp(self):
		if not self.Enable:
			return
		self.mouse.Up()
		self.event()

class AdminTool(ui.ScriptWindow):

	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.ACTION_BAN_CHAT = 0
		self.ACTION_UNBAN_CHAT = 1
		
		self.ACTION_BAN_ACCOUNT = 2
		self.ACTION_UNBAN_ACCOUNT = 3
		
		self.ACTION_BAN_TIME = 4
		self.ACTION_UNBAN_TIME = 5
		
		self.ACTION_BAN_ALL_ACCOUNTS = 6
		self.ACTION_UNBAN_ALL_ACCOUNTS = 7
		

		self.ACTION_BAN_PERMANENTLY = 8
		self.ACTION_UNBAN_PERMANENTLY = 9
		
		self.ACTION_BAN_FILES = 10
		
		self.TYPE_MAX_NUM = 11

		self.Initialize()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Initialize(self):
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/admintool.py")
		except:
			import exception
			exception.Abort("AdminTool.Initialize.LoadObject")
		try:
			self.GetChild("titlebar").SetCloseEvent(self.Close)
		except:
			import exception
			exception.Abort("AdminTool.Initialize.BindObject")

		self.main = {
			"board" : self.GetChild("board"),				
			"selected" : {},
			"btn_block" : self.GetChild("block_button"),
			"box_day" : self.GetChild("ban_result_day"),
			"box_hour" : self.GetChild("ban_result_hour"),
			"box_min" : self.GetChild("ban_result_minute"),
			"box_category_time" : [self.GetChild("ban_result_day_slot"), self.GetChild("ban_result_hour_slot"), self.GetChild("ban_result_minute_slot")],
			"user_name" : self.GetChild("ban_result_user_name"),
			"reason" : self.GetChild("ban_result_reason"),			
		}
	
		for key in xrange(self.TYPE_MAX_NUM):
			if key <= 3:
				self.main["selected"].update({key : CheckBox(self, key, 25 + (key * 60), 120, lambda arg = key: self.OnSelectType(arg))})
			elif key > 3 and key <= 7:
				self.main["selected"].update({key : CheckBox(self, key, 25 + ((key-4) * 60), 140, lambda arg = key: self.OnSelectType(arg))})
			else:
				self.main["selected"].update({key : CheckBox(self, key, 25 + ((key-8) * 60), 160, lambda arg = key: self.OnSelectType(arg))})

		self.main["btn_block"].SAFE_SetEvent(self.OnRecvBanUser)	
		self.OnSelectType(self.ACTION_BAN_CHAT)	
		self.SetCenterPosition()

	def SetName(self, string):
		self.main["user_name"].SetText(string)
	
	def GetTypeSelected(self):
		for i in xrange(self.TYPE_MAX_NUM):
			if self.main["selected"][i].IsSelected():
				return i

	def OnSelectType(self, key):
		for i in xrange(self.TYPE_MAX_NUM):
			if key == i:
				self.main["selected"][i].SetCheck(True)
			else:
				self.main["selected"][i].SetCheck(False)

		self.MakeInterface(self.GetTypeSelected())
		
	def MakeInterface(self, type):
			
		def appendBoxTime(key):
			for wnd in self.main["box_category_time"]:
				if key: 
					wnd.Show()
				else:
					wnd.Hide()

		if type in [self.ACTION_BAN_TIME, self.ACTION_BAN_CHAT]:
			appendBoxTime(True)
			return

		appendBoxTime(False)

	def OnRecvBanUser(self):

		def div(type, key):
			return [key * 24 * 60 * 60, key * 60 * 60, key * 60][type - 1]

		def get(type, key):
			if type is "s":
				return str(self.main[key].GetText())

			return int(self.main[key].GetText())

		def callable(x, y, z):
			return x + y + z
			
		def tokens():
			return get("s", "user_name"), get("s", "reason"), get("i", "box_day"), get("i", "box_hour"), get("i", "box_min")

		user_name, reason, day, hour, minute = tokens()
		net.SendAdminBanManagerPacket(self.GetTypeSelected(), user_name, reason, callable(div(1, day), div(2, hour), div(3, minute)))

	def Destroy(self):
		self.ClearDictionary()

	def Close(self):
		self.Hide()
		constInfo.ADMIN_PANEL_IS_OPEN = 0
		
	def OnPressEscapeKey(self):
		self.Hide()
		constInfo.ADMIN_PANEL_IS_OPEN = 0
		return True

	def OnUpdate(self):
		(x, y) = wndMgr.GetMousePosition()

		def IsCursorSelected(key):
			return self.main["selected"][key].IsIn()

		for key in xrange(self.TYPE_MAX_NUM):
			if IsCursorSelected(key):
				self.toolTip = uiToolTip.ToolTip()
				self.toolTip.SetPosition(x + 25, y)
				self.toolTip.AppendDescription(BAN_DESCRIPTION_TYPE[key], None, 0xffffa879)	

	def Open(self):
		pass