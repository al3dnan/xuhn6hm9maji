import pythonEncode
arrayFirst = ["app", "player", "net", "chr"]
for module_name in arrayFirst:
	module = __import__(pythonEncode.GetModuleName(module_name), fromlist=[module_name])
	globals()[module_name] = module
import ui
import localeInfo
import constInfo
import uiToolTip
import item
import uiCommon

TIP_INDEX_DICT = {
	0 : {
		0 : localeInfo.PARTY_STONE_TIP_1,
		1 : localeInfo.PARTY_STONE_TIP_2,
		2 : localeInfo.PARTY_STONE_TIP_3,
		3 : "",
		4 : localeInfo.PARTY_STONE_TIP_4,
		5 : localeInfo.PARTY_STONE_TIP_5,
	},

	1 : {
		0 : localeInfo.PARTY_STONE_TIP_6,
		1 : localeInfo.PARTY_STONE_TIP_7,
		2 : localeInfo.PARTY_STONE_TIP_8,
		3 : "",
		4 : localeInfo.PARTY_STONE_TIP_9,
		5 : localeInfo.PARTY_STONE_TIP_10,
	},

	2 : {
		0 : localeInfo.PARTY_STONE_TIP_11,
		1 : localeInfo.PARTY_STONE_TIP_12,
		2 : localeInfo.PARTY_STONE_TIP_13,
		3 : localeInfo.PARTY_STONE_TIP_14,
		4 : localeInfo.PARTY_STONE_TIP_15,
		5 : localeInfo.PARTY_STONE_TIP_16,
	},
}
	
class PartyStoneWindow(ui.ScriptWindow):

	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.__Initialize()
		self.__Load()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def __Initialize(self):
		self.titleBar = 0
		self.room_button = []
		self.curTab = 0
		self.TextList = []
		self.TextBoard = None
		self.TextPage = 0
		self.TextPrevButton = None
		self.TextNextButton = None
		
		self.JoinButton = None
		self.WatchButton = None
		self.DeleteButton = None

	def Destroy(self):
		self.ClearDictionary()
		self.__Initialize()

	def __Load_LoadScript(self, fileName):
		try:
			pyScriptLoader = ui.PythonScriptLoader()
			pyScriptLoader.LoadScriptFile(self, fileName)
		except:
			import exception
			exception.Abort("PartyStoneWindow.__Load_LoadScript")

	def __LoadTabPages(self):
		try:
			GetObject = self.GetChild
			self.titleBar 		= GetObject("titlebar")
			self.TextBoard 		= GetObject("TextBoard")
			self.TextPrevButton = GetObject("prev_button")
			self.TextNextButton = GetObject("next_button")
			self.JoinButton 	= GetObject("JoinButton")
			self.WatchButton 	= GetObject("WatchButton")
			self.DeleteButton 	= GetObject("DeleteButton")
			for i in xrange(10):
				self.room_button.append(self.GetChild("room_button%d" % (i)))

		except:
			import exception
			exception.Abort("PartyStoneWindow.__LoadTabPages")
	
	def __Load(self):
		self.__Load_LoadScript("uiscript/partystone.py")
		self.__LoadTabPages()
		self.SetCenterPosition()
		self.titleBar.SetCloseEvent(ui.__mem_func__(self.Close))
		
		self.JoinButton.SetEvent(ui.__mem_func__(self.ClickJoinButton))
		self.WatchButton.SetEvent(ui.__mem_func__(self.ClickWatchButton))
		self.DeleteButton.SetEvent(ui.__mem_func__(self.ClickDeleteButton))
			
		self.ShowText(TIP_INDEX_DICT[self.TextPage])
		self.TextPrevButton.SetEvent(lambda arg=False: self.__OnClickArrow(arg))
		self.TextNextButton.SetEvent(lambda arg=True: self.__OnClickArrow(arg))
		
		self.tabButtonGroup = ui.RadioButtonGroup.Create([
			[self.room_button[0], lambda : self._OnClickTabButton(0), None], 
			[self.room_button[1], lambda : self._OnClickTabButton(1), None],
			[self.room_button[2], lambda : self._OnClickTabButton(2), None], 
			[self.room_button[3], lambda : self._OnClickTabButton(3), None], 
			[self.room_button[4], lambda : self._OnClickTabButton(4), None], 
			[self.room_button[5], lambda : self._OnClickTabButton(5), None], 
			[self.room_button[6], lambda : self._OnClickTabButton(6), None], 
			[self.room_button[7], lambda : self._OnClickTabButton(7), None], 
			[self.room_button[8], lambda : self._OnClickTabButton(8), None], 
			[self.room_button[9], lambda : self._OnClickTabButton(9), None], 
		])
		
	def _OnClickTabButton(self, id):
		self.SetCurTab(id)

	def GetCurTab(self):
		return self.curTab

	def SetCurTab(self, tab):
		self.curTab = tab

	def OnPressEscapeKey(self):
		self.Close()
		return True

	def ClickJoinButton(self):
		net.SendChatPacket("/party_stone_join %d" % (self.curTab))
	def ClickWatchButton(self):
		net.SendChatPacket("/party_stone_watch %d" % (self.curTab))
	def ClickDeleteButton(self):
		net.SendChatPacket("/party_stone_erase %d" % (self.curTab))
		
	def SetInfo(self, arg1, arg2, arg3, arg4, arg5, arg6, arg7, arg8, arg9, arg10):
		StatusNames = [localeInfo.PARTY_STONE_STATE_0,localeInfo.PARTY_STONE_STATE_1,localeInfo.PARTY_STONE_STATE_2]
		self.room_button[0].SetText(StatusNames[int(arg1)])
		self.room_button[1].SetText(StatusNames[int(arg2)])
		self.room_button[2].SetText(StatusNames[int(arg3)])
		self.room_button[3].SetText(StatusNames[int(arg4)])
		self.room_button[4].SetText(StatusNames[int(arg5)])
		self.room_button[5].SetText(StatusNames[int(arg6)])
		self.room_button[6].SetText(StatusNames[int(arg7)])
		self.room_button[7].SetText(StatusNames[int(arg8)])
		self.room_button[8].SetText(StatusNames[int(arg9)])
		self.room_button[9].SetText(StatusNames[int(arg10)])

	def __OnClickArrow(self, Page):
		if Page == True:
			if self.TextPage == 2:
				return
			self.TextPage += 1
			self.ShowText(TIP_INDEX_DICT[self.TextPage])
		else:
			if self.TextPage == 0:
				return
			self.TextPage -= 1
			self.ShowText(TIP_INDEX_DICT[self.TextPage])
		
	def ShowText(self, descList):
		self.TextList = []
		for index, desc in enumerate(descList.itervalues()):
			TextLine = ui.TextLine()
			TextLine.SetParent(self.TextBoard)
			x,y = (0, 15)
			TextLine.SetPosition(x+5, y + 23 * index)
			TextLine.SetFontName(localeInfo.UI_DEF_FONT)
			TextLine.SetHorizontalAlignLeft()
			TextLine.SetWindowHorizontalAlignRight()
			TextLine.Show()
			TextLine.SetText(desc)
			self.TextList.append(TextLine)
			

	def Open(self):
		if self.IsShow():
			self.Close()
			return
		ui.ScriptWindow.Show(self)
		self.Show()
		if not player.IsGameMaster():
			self.DeleteButton.Hide()

	def Close(self):
		self.Hide()
