import dbg
import ui
import pythonEncode
net = __import__(pythonEncode.GetModuleName("net"))
app = __import__(pythonEncode.GetModuleName("app"))
import localeInfo
import constInfo
import uiScriptLocale
import uiToolTip
import item
import time
import wndMgr
import uiscriptlocale
import chat

class PartywarBoardWindow(ui.ScriptWindow):

	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.__Initialize()
		self.__Load()
		

	def __del__(self):
		ui.ScriptWindow.__del__(self)
		self.tooltipitem = None

	def __Initialize(self):
		self.titleBar = 0
		self.curTab = 0

		self.tabButtons = []
		self.pages = []
		
		self.tooltipitem = uiToolTip.ItemToolTip()
		

		self.MembersCount = None
		self.RewardVnum = 0
		self.GroupsCount = None
		
		self.SetButton = None
		self.StartButton = None
		self.StopButton = None
		
		
		self.ItemImage = None

		self.member_button = []
		self.inputReward = None
		self.inputGroups = None
		
		self.type_button = []
		self.time_button = []
		
		
		
		
	def Destroy(self):
		self.ClearDictionary()
		self.__Initialize()

	def __Load_LoadScript(self, fileName):
		try:
			pyScriptLoader = ui.PythonScriptLoader()
			pyScriptLoader.LoadScriptFile(self, fileName)
		except:
			import exception
			exception.Abort("OptionExDialog.__Load_LoadScript")

	def __LoadTabPages(self):
		try:
			GetObject = self.GetChild
			self.titleBar = GetObject("titlebar")
			self.pages.append(self.GetChild("Page1"))
			self.pages.append(self.GetChild("Page2"))
			for i in xrange(2):
				self.tabButtons.append(self.GetChild("Tab%d" % (i+1)))
				self.pages[i].Hide()

		except:
			import exception
			exception.Abort("OptionExDialog.__LoadTabPages")

	def __LoadPage1(self):
		try:
			GetObject = self.GetChild
			self.SetButton = GetObject("SetButton")
			for i in xrange(4):
				self.member_button.append(GetObject("member_button%d" % (i)))
			self.inputReward = GetObject("inputReward")
			self.inputGroups = GetObject("inputGroups")
			
		except:
			import exception
			exception.Abort("OptionExDialog.__LoadPage1")

	def __LoadPage2(self):
		try:
			GetObject = self.GetChild
			self.StartButton = GetObject("StartButton")
			self.StopButton = GetObject("StopButton")
			self.MembersCount = self.GetChild("MembersCount")
			self.GroupsCount = self.GetChild("GroupsCount")
			self.ItemImage = GetObject("ItemImage")
			for i in xrange(3):
				self.time_button.append(GetObject("time_button%d" % (i)))
			for s in xrange(2):
				self.type_button.append(GetObject("type_button%d" % (s)))
			

		except:
			import exception
			exception.Abort("OptionExDialog.__LoadPage2")

	def __Load(self):
		self.__Load_LoadScript("uiscript/partywarboard.py")
		self.__LoadTabPages()
		self.__LoadPage1()
		self.__LoadPage2()
		self.SetCenterPosition()

		self.titleBar.SetCloseEvent(ui.__mem_func__(self.Close))
		
		self.SetButton.SAFE_SetEvent(self.__OnClickSetButton)
		self.StartButton.SAFE_SetEvent(self.__OnClickStartButton)
		self.StopButton.SAFE_SetEvent(self.__OnClickStopButton)
		
		
		self.ItemImage.SetOverInItemEvent(ui.__mem_func__(self.OverInImgItemSlot))
		self.ItemImage.SetOverOutItemEvent(ui.__mem_func__(self.OverOutItem))

		for i in xrange(4):
			self.member_button[i].SetEvent(lambda arg=i: self.__OnClickMemberButton(arg))

		self.member_button[0].Down()
		constInfo.PARTY_WAR_MEMBERS = 2
		
		for i in xrange(3):
			self.time_button[i].SetEvent(lambda arg=i: self.__OnClickTimerButton(arg))
			
		for s in xrange(2):
			self.type_button[s].SetEvent(lambda arg=s: self.__OnClickTypeButton(arg))

		self.type_button[0].Down()
		self.time_button[0].Down()
		constInfo.PARTY_WAR_SETTINGS[0] = 1 ## EVENT
		constInfo.PARTY_WAR_SETTINGS[1] = 5 ## TIMER
		
		
		self.tabButtonGroup = ui.RadioButtonGroup.Create([
			[self.tabButtons[0], lambda : self._OnClickTabButton(0), None], 
			[self.tabButtons[1], lambda : self._OnClickTabButton(1), None], 
		])

	def __ClickRadioButton(self, buttonList, buttonIndex):
		try:
			selButton=buttonList[buttonIndex]
		except IndexError:
			return

		for eachButton in buttonList:
			eachButton.SetUp()

		selButton.Down()
		
		
	def __OnClickMemberButton(self, index):
		self.__ClickRadioButton(self.member_button, index)

		constInfo.PARTY_WAR_MEMBERS = index+2
		
	def __OnClickTypeButton(self, index):
		self.__ClickRadioButton(self.type_button, index)
		constInfo.PARTY_WAR_SETTINGS[0] = index+1
		
	def __OnClickTimerButton(self, index):
		self.__ClickRadioButton(self.time_button, index)

		if index == 0:
			constInfo.PARTY_WAR_SETTINGS[1] = 5
		elif index == 1:
			constInfo.PARTY_WAR_SETTINGS[1] = 10
		else:
			constInfo.PARTY_WAR_SETTINGS[1] = 15
		

	def OverInImgItemSlot(self, slotIndex):
		if self.tooltipitem:
			self.tooltipitem.SetItemToolTip(self.RewardVnum)

	def OverOutItem(self):
		if self.tooltipitem:
			self.tooltipitem.HideToolTip()
			self.tooltipitem.ClearToolTip()
	
	def __OnClickStartButton(self):
		event	= constInfo.PARTY_WAR_SETTINGS[0]
		timer  = constInfo.PARTY_WAR_SETTINGS[1]

		net.SendChatPacket("/start_partywar %d %d" % (event,timer))
	
	def __OnClickStopButton(self):
		net.SendChatPacket("/start_partywar 0 0")
		
	def __OnClickSetButton(self):
		member  = constInfo.PARTY_WAR_MEMBERS
		reward	= self.inputReward.GetText()
		groups	= self.inputGroups.GetText()

		if reward and not reward.isdigit():
			chat.AppendChat(1, localeInfo.PARTY_WAR_REWARD_ERR)
			return
			
		if groups and not groups.isdigit():
			chat.AppendChat(1, localeInfo.PARTY_WAR_REWARD_ERR)
			return
			

		net.SendChatPacket("/set_partywar %d %s %s" % (member,reward,groups))

	def _OnClickTabButton(self, id):
		self.SetCurTab(id)

	def GetCurTab(self):
		return self.curTab

	def SetCurTab(self, tab):
		self.curTab = tab
		self.RefreshTab()
		
	def RefreshTab(self):
		for page in self.pages:
			page.Hide()
		self.pages[self.GetCurTab()].Show()

	def OnPressEscapeKey(self):
		self.Close()
		return True

	def Open(self):
		if self.IsShow():
			self.Close()
			return
		ui.ScriptWindow.Show(self)
		self.SetPartywarBoard(str(self.MembersCount.GetText()), self.RewardVnum, str(self.GroupsCount.GetText()))
		self.Show()
		
	def SetPartywarBoard(self, member, reward, groups):
		self.MembersCount.SetText(str(member))
		self.RewardVnum = int(reward)
		self.GroupsCount.SetText(str(groups))
		self.inputReward.SetText(str(reward))
		self.inputGroups.SetText(str(groups))

	def Close(self):
		self.inputReward.KillFocus()
		self.inputGroups.KillFocus()
		self.OverOutItem()
		self.Hide()
		
	def OnUpdate(self):
		if self.RewardVnum != 0:
			self.ItemImage.SetItemSlot(0, self.RewardVnum, 0)
			self.ItemImage.RefreshSlot()

class PartywarTimerWindow(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.__Initialize()
		self.LoadObject()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def __Initialize(self):
		self.wndBoard = 0
		self.StartTime = 0
		self.LeftTime = None
		
	def Destroy(self):
		self.__Initialize()
		self.ClearDictionary()

	def Open(self):
		self.LoadObject()
		ui.ScriptWindow.Show(self)
		leftTime = max(0, self.StartTime- app.GetTime())
		self.SetPartywarTimer(leftTime)
		
	def LoadObject(self):
		try:
			
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/partywartimer.py")
			
		except:
			import exception
			exception.Abort("Window.LoadObject.LoadObject")
		
		try:
			self.wndBoard = self.GetChild("board")
			self.LeftTime = self.GetChild("LeftTime")
			
		except:
			import exception
			exception.Abort("Window.LoadObject.BindObject")

	def SetPartywarTimer(self, time):
		self.StartTime = app.GetTime()+int(time)
		
	def OnUpdate(self):
		leftTime = max(0, self.StartTime- app.GetTime())
		if leftTime <= 0:
			self.wndBoard.Hide()
			return
			
		leftMin = int((leftTime / 60) % 60)
		leftSecond = int(leftTime % 60)

		if leftTime < 60: # Red Color Under 60 Sec
			self.LeftTime.SetText("|cffe91d1d|H|h %02d:%02d" % (leftMin, leftSecond))
		else:
			self.LeftTime.SetText("%02d:%02d" % (leftMin, leftSecond))
			
class PartyWarButton(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.__Initialize()
		self.LoadObject()

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def __Initialize(self):
		self.wndBoard = 0
		self.StartTime = 0
		self.LeftTime = None
		
	def Destroy(self):
		self.__Initialize()
		self.ClearDictionary()

	def Open(self):
		self.LoadObject()
		ui.ScriptWindow.Show(self)
		leftTime = max(0, self.StartTime- app.GetTime())
		self.SetPartywarTimer(leftTime)
		
	def LoadObject(self):
		try:
			
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/partywarbutton.py")
			
		except:
			import exception
			exception.Abort("Window.LoadObject.LoadObject")
		
		try:
			self.wndBoard = self.GetChild("board")
			self.LeftTime = self.GetChild("LeftTime")
			
			self.buttonJoin = self.GetChild("buttonJoin")
			self.buttonWatch = self.GetChild("buttonWatch")
			
		except:
			import exception
			exception.Abort("Window.LoadObject.BindObject")
			
		self.buttonJoin.SAFE_SetEvent(self.__OnClickJoinButton)
		self.buttonWatch.SAFE_SetEvent(self.__OnClickWatchButton)

	def __OnClickJoinButton(self):
		net.SendChatPacket("/partywar_join join")
	def __OnClickWatchButton(self):
		net.SendChatPacket("/partywar_join watch")

	def SetPartywarTimer(self, time):
		self.StartTime = app.GetTime()+int(time)
		
	def OnUpdate(self):
		leftTime = max(0, self.StartTime- app.GetTime())
		if leftTime <= 0:
			self.wndBoard.Hide()
			self.buttonJoin.Hide()
			self.buttonWatch.Hide()
			return
			
		leftMin = int((leftTime / 60) % 60)
		leftSecond = int(leftTime % 60)

		if leftTime < 60: # Red Color Under 60 Sec
			self.LeftTime.SetText("|cffe91d1d|H|h %02d:%02d" % (leftMin, leftSecond))
		else:
			self.LeftTime.SetText("%02d:%02d" % (leftMin, leftSecond))