import pythonEncode
import ui
import grp
player = __import__(pythonEncode.GetModuleName("player"))
app = __import__(pythonEncode.GetModuleName("app"))
import localeInfo
import constInfo

class Window(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.isLoaded = 0
		self.PositionOut = 0
		self.PositionStartX = 0
		self.PositionStartY = 0
		self.titleBar = None
		self.rankLine = None
		self.rankDataBackground = None
		self.rankData = None
		self.sLogo = ui.AniImageBox()
		self.pLogo = [self.sLogo]
		self.loadingText = None
		constInfo.PLAYER_RANK_WAIT[0] = 0

	def __del__(self):
		ui.ScriptWindow.__del__(self)

	def Destroy(self):
		self.ClearDictionary()
		self.PositionOut = 0
		self.PositionStartX = 0
		self.PositionStartY = 0
		self.titleBar = None
		self.rankLine = None
		self.rankDataBackground = None
		self.rankData = None
		self.sLogo = ui.AniImageBox()
		self.pLogo = [self.sLogo]
		self.loadingText = None
		constInfo.PLAYER_RANK_WAIT[0] = 0

	def LoadWindow(self):
		if self.isLoaded:
			return
		
		self.isLoaded = 1
		
		try:
			pyScrLoader = ui.PythonScriptLoader()
			pyScrLoader.LoadScriptFile(self, "uiscript/playerranking.py")
		except:
			import exception
			exception.Abort("PlayerRankWindow.LoadDialog.LoadScript")
		
		self.DIFFERENCE = 17
		self.BOARD_WIDTH = 368
		
		try:
			self.titleBar = self.GetChild("TitleBar")
		except:
			import exception
			exception.Abort("PlayerRankWindow.LoadDialog.BindObject")
		
		#build
		self.rankLine = []
		self.rankData = {
							"ID" : [],
							"NAME" : [],
							"EMPIRE" : [],
							"GOLD" : [],
		}
		
		self.rankDataBackground = {
							"ID" : [],
							"NAME" : [],
							"EMPIRE" : [],
							"GOLD" : [],
		}
		
		str_lineDown = "d:/ymir work/ui/game/playerranking/line_down.png"
		
		for i in xrange(11):
			lineStep = 24
			yPos = i * lineStep + 64+10
			if i == 10:
				yPos = i * lineStep + 75+10
			
			line = ui.MakeImageBox(self, str_lineDown, 22, yPos)
			self.rankLine.append(line)
			

			ID_BACKGROUND = ui.Bar("TOP_MOST")
			ID_BACKGROUND.SetParent(self.rankLine[i])
			ID_BACKGROUND.SetPosition(6, 2)
			
			ID_BACKGROUND.SetSize(31, 16)
			ID_BACKGROUND.SetColor(grp.GenerateColor(0.0, 0.0, 0.0, 0.0))
			ID_BACKGROUND.Show()
			self.rankDataBackground["ID"].append(ID_BACKGROUND)
			

			NAME_BACKGROUND = ui.Bar("TOP_MOST")
			NAME_BACKGROUND.SetParent(self.rankLine[i])
			NAME_BACKGROUND.SetPosition(55, 2)
			
			NAME_BACKGROUND.SetSize(114, 16)
			NAME_BACKGROUND.SetColor(grp.GenerateColor(0.0, 0.0, 0.0, 0.0))
			NAME_BACKGROUND.Show()
			self.rankDataBackground["NAME"].append(NAME_BACKGROUND)
			

			EMPIRE_BACKGROUND = ui.Bar("TOP_MOST")
			EMPIRE_BACKGROUND.SetParent(self.rankLine[i])
			EMPIRE_BACKGROUND.SetPosition(192+11, 2)
			
			EMPIRE_BACKGROUND.SetSize(22, 16)
			EMPIRE_BACKGROUND.SetColor(grp.GenerateColor(0.0, 0.0, 0.0, 0.0))
			EMPIRE_BACKGROUND.Show()
			self.rankDataBackground["EMPIRE"].append(EMPIRE_BACKGROUND)
			

			GOLD_BACKGROUND = ui.Bar("TOP_MOST")
			GOLD_BACKGROUND.SetParent(self.rankLine[i])
			GOLD_BACKGROUND.SetPosition(241+15, 2)
			
			GOLD_BACKGROUND.SetSize(61, 16)
			GOLD_BACKGROUND.SetColor(grp.GenerateColor(0.0, 0.0, 0.0, 0.0))
			GOLD_BACKGROUND.Show()
			self.rankDataBackground["GOLD"].append(GOLD_BACKGROUND)
			
			ID = ui.MakeTextLine(self.rankDataBackground["ID"][i])
			NAME = ui.MakeTextLine(self.rankDataBackground["NAME"][i])
			EMPIRE = ui.MakeImageBox(self.rankDataBackground["EMPIRE"][i], "d:/ymir work/ui/game/rank/empire_0.sub", -13, 0)
			GOLD = ui.MakeTextLine(self.rankDataBackground["GOLD"][i])
			self.rankData["ID"].append(ID)
			self.rankData["NAME"].append(NAME)
			self.rankData["EMPIRE"].append(EMPIRE)
			self.rankData["GOLD"].append(GOLD)
		

		self.titleBar.SetCloseEvent(ui.__mem_func__(self.Close))

	def AddPlayerRank(self, line, name, gold, empire, last = None):
		if self.rankData != None:
			str_lineUp = "d:/ymir work/ui/game/playerranking/line_up.png"
			str_lineDown = "d:/ymir work/ui/game/playerranking/line_down.png"
			
			if self.rankData["ID"][line]:
				if last != None:
					self.rankData["ID"][line].SetText(str(last))
				else:
					self.rankData["ID"][line].SetText(str(line + 1))
				
				self.rankData["NAME"][line].SetText(str(name))
				self.rankData["EMPIRE"][line].LoadImage("d:/ymir work/ui/game/rank/empire_%s.sub" % empire)
				self.rankData["GOLD"][line].SetText(str(gold))
					

	def AddMyRank(self, line, name, gold, empire, last = None):
		if self.rankData != None:
			str_lineUp = "d:/ymir work/ui/game/playerranking/line_up.png"
			str_lineDown = "d:/ymir work/ui/game/playerranking/line_down.png"
			
			if self.rankData["ID"][10]:
				if last != None:
					self.rankData["ID"][10].SetText(str(last))
				else:
					self.rankData["ID"][10].SetText(str(line))
				
				self.rankData["NAME"][10].SetText(str(name))
				self.rankData["EMPIRE"][10].LoadImage("d:/ymir work/ui/game/rank/empire_%s.sub" % empire)
				self.rankData["GOLD"][10].SetText(str(gold))

	def ShowLogo(self):
		for i in self.pLogo:
			i.SetParent(self)
			#i.ResetFrame()
			i.Show()
			i.SetDelay(2.5)
			for j in range(1, 31):
				image_file = "main_loading/loading/img%04d.png" % j
				i.AppendImage(image_file)
			i.SetPosition(170, 150)
			i.SetSize(32, 55)
			
		self.loadingText = ui.TextLine()
		self.loadingText.SetParent(self)
		self.loadingText.SetText("Loading")
		self.loadingText.SetFontName("Tahoma:16")
		self.loadingText.SetFontColor(1.0, 1.0, 1.0)
		self.loadingText.SetPosition(170+63, 150+60)
		self.loadingText.Show()

	def OnUpdate(self):
		if constInfo.PLAYER_RANK_WAIT[0] > app.GetTime():
			if not self.sLogo.IsShow():
				self.ShowLogo()
			if self.loadingText != None:
				leftTime = max(0, constInfo.PLAYER_RANK_WAIT[0] - app.GetTime())
				leftSecond = int(leftTime % 60)
				leftMilSecond = int((leftTime * 12) % 10)
				self.loadingText.SetText("Loading %d.%d" % (leftSecond, leftMilSecond))
		else:
			self.sLogo.Hide()
			if self.loadingText != None:
				self.loadingText.Hide()
	
	def IsOpened(self):
		if self.IsShow() and self.isLoaded:
			return True
		
		return False

	def Open(self):
		if self.IsOpened():
			return
		
		for i in xrange(11):
			self.AddPlayerRank(i, "", "0", "0", "0")
			self.AddMyRank(11, "", "0", "0", "0")
		
		self.PositionOut = 0
		(self.PositionStartX, self.PositionStartY, z) = player.GetMainCharacterPosition()
		self.Show()

	def Close(self):
		self.Hide()

	def OnPressEscapeKey(self):
		self.Close()
		return True

