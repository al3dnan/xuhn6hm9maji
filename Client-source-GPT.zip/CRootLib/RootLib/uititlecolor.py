import pythonEncode
import ui
import grp
player = __import__(pythonEncode.GetModuleName("player"))
import chat
net = __import__(pythonEncode.GetModuleName("net"))
import constInfo
import wndMgr
import localeInfo
class ChangeTitleColorWindow(ui.ScriptWindow):
	def __init__(self):
		ui.ScriptWindow.__init__(self)
		self.components = [[]]
		self.rgb_hex = ""
		self.TitleText = None
		self.TitleSlot = None
		self.__LoadWindow()

	def __del__(self):
		ui.ScriptWindow.__del__(self)
		self.components = None

	def __LoadWindow(self):
		gui = [
			[[ui.BoardWithTitleBar, ""], [200, 240], [wndMgr.GetScreenWidth()/2 - 200, wndMgr.GetScreenHeight()/2 - 240], [["SetCloseEvent", [self.Close]],["SetTitleName", [localeInfo.TITLE_COLOR_TITLE]]], ["attach","movable"]],
			[[ui.Bar, 0], [180,5], [10,30], [["SetColor", [grp.GenerateColor(1.0, 0.0, 0.0, 1.0)]]], []],
			[[ui.SliderBar, 0], [0,0], [10,40], [["SetEvent", [lambda : self.__OnChangeSliderBar()]], ["SetSliderPos", [0.0]]], []],
			[[ui.Bar, 0], [180,5], [10,70], [["SetColor", [grp.GenerateColor(0.0, 1.0, 0.0, 1.0)]]], []],
			[[ui.SliderBar, 0], [0,0], [10,80], [["SetEvent", [lambda : self.__OnChangeSliderBar()]], ["SetSliderPos", [0.0]]], []],
			[[ui.Bar, 0], [180,5], [10,110], [["SetColor", [grp.GenerateColor(0.0, 0.0, 1.0, 1.0)]]], []],
			[[ui.SliderBar, 0], [0,0], [10,120], [["SetEvent", [lambda : self.__OnChangeSliderBar()]], ["SetSliderPos", [0.0]]], []],
			[[ui.Bar, 0], [180,35], [10,195], [["SetColor", [grp.GenerateColor(0.0, 0.0, 0.0, 1.0)]]], []],
			[[ui.Button, 0], [0, 0], [70,203], [["SetUpVisual", ["d:/ymir work/ui/public/Middle_Button_01.sub"]],["SetOverVisual", ["d:/ymir work/ui/public/Middle_Button_02.sub"]], ["SetDownVisual", ["d:/ymir work/ui/public/Middle_Button_03.sub"]], ["SetText", ["Ok"]], ["SetEvent", [lambda : self.__OnClickBtnOK()]]], []],
		];CreateGUI(gui, self.components, 0)
		
		SlotBar = ui.SlotBar()
		SlotBar.SetParent(self.components[0][0])
		SlotBar.SetSize(135, 18)
		SlotBar.SetPosition(0, 160)
		SlotBar.SetWindowHorizontalAlignCenter()
		SlotBar.Show()
		self.TitleSlot = SlotBar

		titleName = ui.EditLine()
		titleName.SetParent(self.TitleSlot)
		titleName.SetPosition(-2, 2)
		titleName.SetSize(135, 17)
		titleName.SetMax(24)
		titleName.SetFocus()
		titleName.Show()
		self.TitleText = titleName
		
		self.TitleSlot.UpdateRect()
		self.TitleText.UpdateRect()
		self.components[0][0].UpdateRect()
		

	def __OnClickToggleButton(self):
		self.components[0][2].SetSliderPos(0)
		self.components[0][4].SetSliderPos(0)
		self.components[0][6].SetSliderPos(0)
		self.components[0][7].SetColor(grp.GenerateColor(0,0,0, 1.0))

	def ConvertTitle(self):
		my_string = self.TitleText.GetText()
		my_string = my_string.replace(" ", "|")
		return str(my_string)
		
	def __OnClickBtnOK(self):
		r = int(self.components[0][2].GetSliderPos() * 255)
		g = int(self.components[0][4].GetSliderPos() * 255)
		b = int(self.components[0][6].GetSliderPos() * 255)

		r = min(max(r, 0), 255)
		g = min(max(g, 0), 255)
		b = min(max(b, 0), 255)

		color_hex_str = "0x{:02X}{:02X}{:02X}".format(r, g, b)

		#chat.AppendChat(1, "Color: r:{} g:{} b:{} ".format(r, g, b) + color_hex_str + self.TitleText.GetText())
		net.SendChatPacket("/title_color %s %s" % (self.ConvertTitle(), color_hex_str))
		self.Close()
		

	def __OnChangeSliderBar(self):
		self.components[0][7].SetColor(grp.GenerateColor(self.components[0][2].GetSliderPos(),self.components[0][4].GetSliderPos(),self.components[0][6].GetSliderPos(), 1.0))

	def SetPosition(self, posx, posy):
		self.components[0][0].SetPosition(posx, posy)

	def OnPressEscapeKey(self):
		self.Close()
		return True
		
	def Close(self):
		self.components[0][0].Hide()
		self.Hide()
		constInfo.TITLE_COLOR_WND = False
		

def CreateGUI(GUIobjects, list, arrpos):
	for object in GUIobjects:
		Object = object[0][0]()
		if object[0][1] != "":
			Object.SetParent(list[0][object[0][1]])
		if object[1][0] + object[1][1] != 0:
			Object.SetSize(object[1][0], object[1][1])
		if object[2][0] + object[2][1] != 0:
			Object.SetPosition(object[2][0], object[2][1])
		
		for command in object[3]:
			cmd = command[0]
			attr = getattr(Object, cmd)
			if callable(attr):
				argument = command[1]
				length = len(argument)
				if length == 1:
					if argument[0] == "":
						attr()
					else:
						attr(argument[0])
				elif length == 2:
					attr(argument[0], argument[1])
				elif length == 3:
					attr(argument[0], argument[1], argument[2])
				elif length == 4:
					attr(argument[0], argument[1], argument[2], argument[3])
		
		for flag in object[4]:
			Object.AddFlag(str(flag))
		
		Object.Show()
		list[arrpos].append(Object)
