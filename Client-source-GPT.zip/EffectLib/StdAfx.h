#pragma once

//#include <crtdbg.h>

#include "../eterBase/StdAfx.h"

#include "../eterBase/Utils.h"
#include "../eterBase/Timer.h"
#include "../eterBase/CRC32.h"
#include "../eterBase/Debug.h"

#include "../eterLib/StdAfx.h"
#include "../eterLib/TextFileLoader.h"

#include "../milesLib/StdAfx.h"

/*
#include "FrameController.h"

#include "EffectElementBase.h"
#include "EffectElementBaseInstance.h"

#include "ParticleProperty.h"
#include "ParticleInstance.h"
#include "EmitterProperty.h"

#include "ParticleSystemData.h"
#include "ParticleSystemInstance.h"

#include "EffectMesh.h"
#include "EffectMeshInstance.h"

#include "SimpleLightData.h"
#include "SimpleLightInstance.h"

#include "EffectData.h"
#include "EffectInstance.h"

#include "EffectManager.h"
*/

