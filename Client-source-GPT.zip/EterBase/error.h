#pragma once
extern void SetEterExceptionHandler();

