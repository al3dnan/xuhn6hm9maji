#include "stdafx.h"
namespace { char dummy; }; // solve warning lnk4221

