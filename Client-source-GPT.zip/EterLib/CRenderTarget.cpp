﻿#include "StdAfx.h"
#include "CRenderTarget.h"
#include "../EterLib/Camera.h"
#include "../EterLib/CRenderTargetManager.h"
#include "../EterPythonLib/PythonGraphic.h"

#include "../EterBase/CRC32.h"
#include "../GameLib/GameType.h"
#include "../GameLib/MapType.h"
#include "../GameLib/ItemData.h"
#include "../GameLib/ActorInstance.h"
#include "../UserInterface/InstanceBase.h"
#include "../UserInterface/Locale_inc.h"
#ifdef ENABLE_SKILL_PREVIEW
#include "../GameLib/ItemManager.h"
#endif
#include "ResourceManager.h"

CRenderTarget::CRenderTarget(const DWORD width, const DWORD height) : 
	m_pModel(nullptr),
	m_background(nullptr),
	m_modelRotation(0),
#ifdef ENABLE_MODEL_RENDER_ZOOM
	m_fEyeY(0.0f),
	m_fZoomY(0.0f),
	m_fTargetHeight(0.0f),
	m_fTargetY(0.0f),
#endif
	m_visible(false)
{
	auto pTex = new CGraphicRenderTargetTexture;
	if (!pTex->Create(width, height, D3DFMT_X8R8G8B8, D3DFMT_D16)) {
		delete pTex;
		TraceError("CRenderTarget::CRenderTarget: Could not create CGraphicRenderTargetTexture %dx%d", width, height);
		throw std::runtime_error("CRenderTarget::CRenderTarget: Could not create CGraphicRenderTargetTexture");
	}

	m_renderTargetTexture = std::unique_ptr<CGraphicRenderTargetTexture>(pTex);
}

CRenderTarget::~CRenderTarget()
{
#ifdef ENABLE_MODEL_RENDER_ZOOM
	m_pModel = nullptr;
	m_background = NULL;
	m_fEyeY = 0.0f;
	m_fZoomY = 0.0f;
	m_fTargetHeight = 0.0f;
	m_fTargetY = 0.0f;
	m_visible = false;
#endif
}

void CRenderTarget::SetVisibility(bool isShow)
{
	m_visible = isShow;
}
void CRenderTarget::SetArmor(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;
	m_pModel->ChangeArmor(vnum);
}

void CRenderTarget::SetWeapon(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;
	m_pModel->ChangeWeapon(vnum);
}

void CRenderTarget::SetAcce(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;
	m_pModel->ChangeAcce(vnum - 85000);
}

void CRenderTarget::ChangeHair(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;
	m_pModel->ChangeHair(vnum);
}
#ifdef __ITEM_SHINING_RENDER__
void CRenderTarget::ChangeWeaponShining(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;

	m_pModel->SetShining(0, vnum);
	//m_pModel->GetGraphicThingInstancePtr()->ClearAttachingEffect();
	m_pModel->Refresh(CRaceMotionData::NAME_WAIT, true);
}

void CRenderTarget::ChangeArmorShining(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;

	m_pModel->SetShining(1, vnum);
	//m_pModel->GetGraphicThingInstancePtr()->ClearAttachingEffect();
	m_pModel->Refresh(CRaceMotionData::NAME_WAIT, true);
}
#endif
void CRenderTarget::RenderTexture() const
{
	m_renderTargetTexture->Render();
}

void CRenderTarget::SetRenderingRect(RECT* rect) const
{
	m_renderTargetTexture->SetRenderingRect(rect);
}

void CRenderTarget::CreateTextures() const
{
	m_renderTargetTexture->CreateTextures();
}

void CRenderTarget::ReleaseTextures() const
{
	m_renderTargetTexture->ReleaseTextures();
}

void CRenderTarget::SelectModel(const DWORD index)
{
	CInstanceBase::SCreateData kCreateData{};

	kCreateData.m_bType = index < 9 ? CActorInstance::TYPE_PC : CActorInstance::TYPE_NPC;
	kCreateData.m_dwRace = index;

	auto model = std::make_unique<CInstanceBase>();
	if (!model->Create(kCreateData))
	{
		if (m_pModel)
		{
			m_pModel.reset();
		}
		return;
	}

	m_pModel = std::move(model);

#ifndef ENABLE_MODEL_RENDER_ZOOM
	m_pModel->NEW_SetPixelPosition(TPixelPosition(0, 0, 0));
#endif
#ifdef ENABLE_FIX_RENDER_LOD
	m_pModel->GetGraphicThingInstancePtr()->SetSkipLod(true);
#endif
	m_pModel->GetGraphicThingInstancePtr()->ClearAttachingEffect();
	m_modelRotation = 0.0f;
	m_pModel->Refresh(CRaceMotionData::NAME_WAIT, true);
	m_pModel->SetLoopMotion(CRaceMotionData::NAME_WAIT);
	m_pModel->SetAlwaysRender(true);
	m_pModel->SetRotation(0.0f);
#ifdef ENABLE_MODEL_RENDER_ZOOM
	m_pModel->NEW_SetPixelPosition(TPixelPosition(0.0f, 0.0f, 0.0f));
	CActorInstance& rkActor = m_pModel->GetGraphicThingInstanceRef();
	float fHeight = rkActor.GetHeight();
	m_fEyeY = fHeight;
	m_fZoomY = 0.0f;
	m_fTargetY = 0.0f;
	m_fTargetHeight = m_fEyeY * 8.9f / 140.0f;

	CCameraManager::instance().SetCurrentCamera(CCameraManager::SHOPDECO_CAMERA);
	CCamera* pCam = CCameraManager::instance().GetCurrentCamera();
	pCam->SetTargetHeight(m_fEyeY / 2.0f);
	CCameraManager::instance().ResetToPreviousCamera();
#else
	auto& camera_manager = CCameraManager::instance();
	camera_manager.SetCurrentCamera(CCameraManager::SHOPDECO_CAMERA);
	camera_manager.GetCurrentCamera()->SetTargetHeight(110.0);
	camera_manager.ResetToPreviousCamera();
#endif
}

#ifdef ENABLE_MODEL_RENDER_ZOOM
void CRenderTarget::SetZoom(bool bZoom)
{
	if (!m_pModel)
		return;

	float eyeYTimes8_9 = m_fEyeY * 8.9f;
	float zoomAmount = 26.0f * m_fTargetHeight; // Speed Doubled 26x Times

	if (bZoom)
	{
		m_fZoomY -= zoomAmount;
		float v3 = -(eyeYTimes8_9 - m_fEyeY * 3.0f);
		m_fZoomY = fmax(v3, m_fZoomY);
	}
	else
	{
		m_fZoomY += zoomAmount;
		float v6 = 14000.0f - eyeYTimes8_9;
		float v7 = eyeYTimes8_9 + m_fEyeY * 5.0f;
		m_fZoomY = fmin(m_fZoomY, v6);
		m_fZoomY = fmin(m_fZoomY, v7);
	}
}
#endif

void CRenderTarget::SetScale(float x, float y, float z)
{
	m_pModel->GetGraphicThingInstancePtr()->SetScale(x, y, z, true);
}

bool CRenderTarget::CreateBackground(const char* imgPath, const DWORD width, const DWORD height)
{
	if (m_background)
		return false;

	m_background = std::make_unique<CGraphicImageInstance>();

	const auto graphic_image = dynamic_cast<CGraphicImage*>(CResourceManager::instance().GetResourcePointer(imgPath));
	if (!graphic_image)
	{
		m_background.reset();
		return false;
	}

	m_background->SetImagePointer(graphic_image);
	m_background->SetScale(static_cast<float>(width) / graphic_image->GetWidth(), static_cast<float>(height) / graphic_image->GetHeight());
	return true;
}

void CRenderTarget::RenderBackground() const
{
	if (!m_visible)
		return;

	if (!m_background)
		return;

	auto& rectRender = *m_renderTargetTexture->GetRenderingRect();
	m_renderTargetTexture->SetRenderTarget();

	CGraphicRenderTargetTexture::Clear();
	CPythonGraphic::Instance().SetInterfaceRenderState();

	//const auto width = static_cast<float>(rectRender.right - rectRender.left);
	//const auto height = static_cast<float>(rectRender.bottom - rectRender.top);

	//CPythonGraphic::Instance().SetViewport(0.0f, 0.0f, width, height);

	m_background->Render();
	m_renderTargetTexture->ResetRenderTarget();
	//CPythonGraphic::Instance().RestoreViewport();
}

void CRenderTarget::UpdateModel()
{
	if (!m_visible || !m_pModel)
		return;

	if (m_modelRotation < 360.0f)
		m_modelRotation += 1.0f;
	else
		m_modelRotation = 0.0f;

	m_pModel->SetRotation(m_modelRotation);
	m_pModel->Transform();
	m_pModel->GetGraphicThingInstanceRef().RotationProcess();
#ifdef ENABLE_SKILL_PREVIEW
	m_pModel->Update();
#endif
}

void CRenderTarget::DeformModel() const
{
	if (!m_visible)
		return;

	if (m_pModel)
		m_pModel->Deform();
}

#ifdef ENABLE_MODEL_RENDER_ZOOM
void CRenderTarget::RenderModel() const
{
	if (!m_visible)
		return;

	auto& python_graphic = CPythonGraphic::Instance();
	auto& camera_manager = CCameraManager::instance();
	auto& state_manager = CStateManager::Instance();
	auto& rectRender = *m_renderTargetTexture->GetRenderingRect();

	if (!m_pModel)
		return;

	m_renderTargetTexture->SetRenderTarget();

	if (!m_background)
	{
		m_renderTargetTexture->Clear();
	}

	python_graphic.ClearDepthBuffer();
	
	const auto fov = python_graphic.GetFOV();
	const auto aspect = python_graphic.GetAspect();
	const auto near_y = python_graphic.GetNear();
	const auto far_y = python_graphic.GetFar();

	const auto width = static_cast<float>(rectRender.right - rectRender.left);
	const auto height = static_cast<float>(rectRender.bottom - rectRender.top);

	BOOL bIsFog = STATEMANAGER.GetRenderState(D3DRS_FOGENABLE);
	STATEMANAGER.SetRenderState(D3DRS_FOGENABLE, 0);

	CCameraManager::instance().SetCurrentCamera(CCameraManager::SHOPDECO_CAMERA);
	CCamera* pCam = CCameraManager::instance().GetCurrentCamera();

	python_graphic.SetViewport(0.0f, 0.0f, width, height);
	python_graphic.PushState();

	// YMD.2021.01.12.Owsap - Model Height
	// NOTE : Actor's Height / 2 ( ~ mid camera position)
	CActorInstance& rkActor = m_pModel->GetGraphicThingInstanceRef();
	float fActorHeight = rkActor.GetHeight();

	D3DXVECTOR3 v3Eye(0.0f, -(m_fEyeY * 8.9f + m_fZoomY), 0.0f); // x, y z
	D3DXVECTOR3 v3Target(0.0f, m_fTargetY, fActorHeight / 2); // x, y, z
	D3DXVECTOR3 v3Up(0.0f, 0.0f, 1.0f);
	pCam->SetViewParams(v3Eye, v3Target, v3Up);
	
	python_graphic.UpdateViewMatrix();

	python_graphic.SetPerspective(10.0f, width / height, 100.0f, 15000.0f);

	m_pModel->Render();
	m_pModel->GetGraphicThingInstanceRef().RenderAllAttachingEffect();
	camera_manager.ResetToPreviousCamera();
	python_graphic.RestoreViewport();
	python_graphic.PopState();
	python_graphic.SetPerspective(fov, aspect, near_y, far_y);
	m_renderTargetTexture->ResetRenderTarget();
	state_manager.SetRenderState(D3DRS_FOGENABLE, FALSE);
}
#else
void CRenderTarget::RenderModel() const
{
	if (!m_visible)
	{
		return;
	}

	auto& python_graphic = CPythonGraphic::Instance();
	auto& camera_manager = CCameraManager::instance();
	auto& state_manager = CStateManager::Instance();

	auto& rectRender = *m_renderTargetTexture->GetRenderingRect();

	if (!m_pModel)
	{
		return;
	}

	m_renderTargetTexture->SetRenderTarget();

	if (!m_background)
	{
		m_renderTargetTexture->Clear();
	}

	python_graphic.ClearDepthBuffer();

	const auto fov = python_graphic.GetFOV();
	const auto aspect = python_graphic.GetAspect();
	const auto near_y = python_graphic.GetNear();
	const auto far_y = python_graphic.GetFar();

	const auto width = static_cast<float>(rectRender.right - rectRender.left);
	const auto height = static_cast<float>(rectRender.bottom - rectRender.top);

	state_manager.SetRenderState(D3DRS_FOGENABLE, FALSE);

	python_graphic.SetViewport(0.0f, 0.0f, width, height);

	python_graphic.PushState();

	camera_manager.SetCurrentCamera(CCameraManager::SHOPDECO_CAMERA);
	camera_manager.GetCurrentCamera()->SetViewParams(
		D3DXVECTOR3{ 0.0f, -1500.0f, 600.0f },
		D3DXVECTOR3{ 0.0f, 0.0f, 95.0f },
		D3DXVECTOR3{ 0.0f, 0.0f, 1.0f }
	);

	python_graphic.UpdateViewMatrix();

	python_graphic.SetPerspective(10.0f, width / height, 100.0f, 3000.0f);

	m_pModel->Render();
	m_pModel->GetGraphicThingInstanceRef().RenderAllAttachingEffect();
	camera_manager.ResetToPreviousCamera();
	python_graphic.RestoreViewport();
	python_graphic.PopState();
	python_graphic.SetPerspective(fov, aspect, near_y, far_y);
	m_renderTargetTexture->ResetRenderTarget();
	state_manager.SetRenderState(D3DRS_FOGENABLE, FALSE);
}
#endif

#ifdef ENABLE_MODEL_RENDER_ROTATE
void CRenderTarget::SetModelRotation(float value)
{
	m_modelRotation += value*2;
}
#endif

#ifdef ENABLE_SKILL_PREVIEW
DWORD CRenderTarget::RaceMatchesAntiflag(DWORD race, DWORD vnum)
{
	CItemData* pItemData;
	if (!CItemManager::Instance().GetItemDataPointer(vnum, &pItemData))
		return race;

	DWORD Job = RaceToJob(race);
	DWORD Sex = RaceToSex(race); //male 1

	//basic
	if ((Job == 0) && (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_WARRIOR)))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 0;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 4;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 0;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 4;

		if (Sex)
			return 0;
		else
			return 4;
	}
	else if ((Job == 1) && (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_ASSASSIN)))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 5;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 1;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 5;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 1;

		if (Sex)
			return 5;
		else
			return 1;
	}
	else if ((Job == 2) && (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_SURA)))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 2;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 6;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 2;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 6;

		if (Sex)
			return 2;
		else
			return 6;
	}
	else if ((Job == 3) && (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_SHAMAN)))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 7;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 3;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 7;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 3;

		if (Sex)
			return 7;
		else
			return 3;
	}
#ifdef ENABLE_WOLFMAN_CHARACTER
	else if ((Job == 4) && (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_WOLFMAN)))
	{
		return 8;
	}
#endif

	//failover
	if (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_WARRIOR))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 0;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 4;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 0;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 4;

		if (Sex)
			return 0;
		else
			return 4;
	}
	else if (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_ASSASSIN))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 5;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 1;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 5;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 1;

		if (Sex)
			return 5;
		else
			return 1;
	}
	else if (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_SURA))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 2;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 6;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 2;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 6;

		if (Sex)
			return 2;
		else
			return 6;
	}
	else if (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_SHAMAN))
	{
		if (Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 7;

		if (!Sex && pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 3;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_FEMALE))
			return 7;

		if (pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_MALE))
			return 3;

		if (Sex)
			return 7;
		else
			return 3;
	}
#ifdef ENABLE_WOLFMAN_CHARACTER
	else if (!pItemData->IsAntiFlag(CItemData::ITEM_ANTIFLAG_WOLFMAN))
	{
		return 8;
	}
#endif

	return race;
}

DWORD GetDefaulWeaponBySkillID(UINT uSkillID)
{
	switch (uSkillID)
	{
		case 31: case 32: case 33: case 34: case 35:
			return 1009;
			
		case 46: case 47: case 48:
		case 49: case 50: case 51:
			return 2009;
			
		case 91: case 92: case 93: case 94:
		case 95: case 96: case 106: case 107:
		case 108: case 109: case 110: case 111:
			return 7009;

		default:
			return 19;
	}
}

DWORD GetDefaulArmorRace(DWORD dwRace)
{
	switch (dwRace)
	{
		case CRaceData::MAIN_RACE_WARRIOR_M:
		case CRaceData::MAIN_RACE_WARRIOR_W:
			return 11209;
		case CRaceData::MAIN_RACE_ASSASSIN_W:
		case CRaceData::MAIN_RACE_ASSASSIN_M:
			return 11409;
		case CRaceData::MAIN_RACE_SURA_M:
		case CRaceData::MAIN_RACE_SURA_W:
			return 11609;
		case CRaceData::MAIN_RACE_SHAMAN_W:
		case CRaceData::MAIN_RACE_SHAMAN_M:
			return 11809;
	}
}

void CRenderTarget::SetSkillPreview(DWORD vnum)
{
	if (!m_visible || !m_pModel)
		return;

	CItemData* pItemData;
	if (!CItemManager::Instance().GetItemDataPointer(vnum, &pItemData))
		return;

	const DWORD dwRace = RaceMatchesAntiflag(m_pModel->GetRace(), pItemData->GetIndex());
	
	CInstanceBase::SCreateData kCreateData{};
	UINT uSkill = pItemData->GetValue(3);
	BYTE bSkillSet = pItemData->GetValue(4);
	kCreateData.m_bType = CActorInstance::TYPE_PC;
	kCreateData.m_dwRace = dwRace;
	kCreateData.m_dwWeapon = GetDefaulWeaponBySkillID(uSkill);
	kCreateData.m_dwArmor = GetDefaulArmorRace(dwRace);

	auto model = std::make_unique<CInstanceBase>();
	if (!model->Create(kCreateData))
	{
		if (m_pModel)
			m_pModel.reset();
		return;
	}

	m_pModel = std::move(model);
	m_pModel->NEW_SetPixelPosition(TPixelPosition(0, 0, 0));
#ifdef ENABLE_FIX_RENDER_LOD
	m_pModel->GetGraphicThingInstancePtr()->SetSkipLod(true);
#endif
	m_pModel->GetGraphicThingInstancePtr()->ClearAttachingEffect();
	m_modelRotation = 0.0f;
	m_pModel->Refresh(CRaceMotionData::NAME_WAIT, true);
	m_pModel->SetLoopMotion(CRaceMotionData::NAME_WAIT);
	m_pModel->SetAlwaysRender(true);
	m_pModel->SetRotation(0.0f);

	auto& camera_manager = CCameraManager::instance();
	camera_manager.SetCurrentCamera(CCameraManager::SHOPDECO_CAMERA);
	camera_manager.GetCurrentCamera()->SetTargetHeight(110.0);
	camera_manager.ResetToPreviousCamera();
	

	m_pModel->SetSkillPreview(uSkill, bSkillSet);
}
#endif

