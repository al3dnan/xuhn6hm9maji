﻿#pragma once

#include <memory>
#include "GrpRenderTargetTexture.h"
#include "../UserInterface/Locale_inc.h"

class CInstanceBase;
class CGraphicImageInstance;

class CRenderTarget
{
	using TCharacterInstanceMap = std::map<DWORD, CInstanceBase*>;

	public:
		CRenderTarget(DWORD width, DWORD height);
		~CRenderTarget();

		void SetVisibility(bool isShow);
		void RenderTexture() const;
		void SetRenderingRect(RECT* rect) const;

		void SelectModel(DWORD index);
		void SetScale(float x, float y, float z);
		bool CreateBackground(const char* imgPath, DWORD width, DWORD height);
		void RenderBackground() const;
		void UpdateModel();
		void DeformModel() const;
		void RenderModel() const;
#ifdef ENABLE_MODEL_RENDER_ZOOM
		void SetZoom(bool bZoom);
#endif
		void SetWeapon(DWORD dwVnum);
		void SetArmor(DWORD vnum);
		void SetAcce(DWORD vnum);
		void ChangeHair(DWORD vnum);
		void CreateTextures() const;
		void ReleaseTextures() const;
#ifdef __ITEM_SHINING_RENDER__
		void ChangeWeaponShining(DWORD dwVnum);
		void ChangeArmorShining(DWORD dwVnum);
#endif
#ifdef ENABLE_MODEL_RENDER_ROTATE
		void 	SetModelRotation(float value);
#endif
#ifdef ENABLE_SKILL_PREVIEW
		DWORD RaceMatchesAntiflag(DWORD race, DWORD vnum);
		void  SetSkillPreview(DWORD vnum);
#endif
	private:
		std::unique_ptr<CInstanceBase> m_pModel;
		std::unique_ptr<CGraphicImageInstance> m_background;
		std::unique_ptr<CGraphicRenderTargetTexture> m_renderTargetTexture;
		float m_modelRotation;
		bool m_visible;
#ifdef ENABLE_MODEL_RENDER_ZOOM
		float m_fEyeY;
		float m_fTargetY;
		float m_fTargetHeight;
		float m_fZoomY;
#endif

};
