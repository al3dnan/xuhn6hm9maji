#ifndef __INC_METIN2_COMMON_DEFINES_H__
#define __INC_METIN2_COMMON_DEFINES_H__

//////////////////////////////////////////////////////////////////////////
// ### General Features ###
//#define ENABLE_QUEST_CATEGORY
#define ENABLE_D_NJGUILD
#define ENABLE_FULL_NOTICE
#define ENABLE_NEWSTUFF
#define ENABLE_PORT_SECURITY
#define ENABLE_BELT_INVENTORY_EX
#define ENABLE_CMD_WARP_IN_DUNGEON
// #define ENABLE_ITEM_ATTR_COSTUME
// #define ENABLE_SEQUENCE_SYSTEM

enum eCommonDefines {
	MAP_ALLOW_LIMIT = 32, // 32 default
};
// ### General Features ###
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// ### Special Features ###
#define ENABLE_QUIVER_SYSTEM
#define ENABLE_PC_KILL_REWARDS
#ifdef ENABLE_PC_KILL_REWARDS
#define ENABLE_HP_KILL_REWARD
#define ENABLE_SP_KILL_REWARD
#define ENABLE_EXP_KILL_REWARD
#define KILLS_TO_LEVEL_UP 50
#endif
#define __ITEM_SHINING__
#define ENABLE_GACHA_SYSTEM
#define ENABLE_EXTENDED_PET_SYSTEM
#define ENABLE_PERMA_ACCESSORY_SYSTEM TRUE
#define ENABLE_PERMA_BLEND_SYSTEM TRUE
#define ENABLE_UNLIMETED_ELIXER TRUE
#define ENABLE_WAIT_FOR_SUMMON
#define ENABLE_PRESENT_MOUNT_SYSTEM
#define MOUNT_DISTANCE_FIX
#define ENABLE_FULL_GUILD				// انشاء رابطة كاملة
#define ENABLE_QUICK_GUILD				// إنشاء رابطة بدون وقت وبدون يانغ
#define __TITLE_SYSTEM_YUMA__
#define __COSTUMIZED_TITLE__
#define COSTUMIZED_TITLE_ITEM 69500
#define AUTO_ATTRIBUTE_SYSTEM
#ifdef AUTO_ATTRIBUTE_SYSTEM
#define INFINITE_AUTO_ATTRIBUTE TRUE
#define ADDONTYPE_AUTO_ATTRIBUTE FALSE
#define WEAPON_CAN_DOUBLE_HUMAN TRUE
#endif
#define WJ_ENABLE_TRADABLE_ICON
#define ENABLE_PARTY_MEMBER_COUNT	16			// 8 Original
#define ENABLE_PARTY_MEMBER_RANGE	50000		// 5k Original
#define PARTY_ATTACKERS_MAX	16					// 1 Original
#define PARTY_TANKERS_MAX	16					// 1 Original
#define __VIEW_TARGET_PLAYER_HP__
#define ENABLE_YMIR_AFFECT_FIX
#define ENABLE_ADMIN_BAN_MANAGER
#define ENABLE_NEW_DUEL
#define NEW_DUEL_MAP1 63
#define NEW_DUEL_MAP2 61
#define NEW_DUEL_MAP3 300
#define DISABLE_WARRIOR_JEONGWI_DMG				// إزالة الضرر الإضافة على النشوة
#define NEW_PLAYERS_REWARDS
#define NEW_PLAYERS_START_LEVEL 120				// مستوى دخول اللاعبين
#define MAIN_PLAYER_SPEED 200					// سرعة الهجوم والحركة لجميع اللاعبين عند الدخول
#define ENABLE_RECOVERY_ON_RESTART
#define ENABLE_PLAYER_EMPIRE
#define RANK_WINDOW_SYSTEM
#define ENCODE_ATTACK_COMMAND
#define ENABLE_SKILL_COLOR_SYSTEM
#define ENABLE_SKILL_COLOR_TICKET
#define ENABLE_FAST_MOUNTS
#define EXTRA_MOUNT_SPEED 80					// سرعة الدواب الإضافية
// #define ENABLE_BUFF_ITEM_SYSTEM
// #ifdef ENABLE_BUFF_ITEM_SYSTEM
// #define ENABLE_BUFF_ITEM_EXPIRE
// #define BUFF_ITEM_IQ 102						// ذكاء بند البف
// #endif
#define ENABLE_FULL_SKILL_STAT
#define ENABLE_STABLE_HP
#define DISABLE_KILL_ALIGN_PENALTY
#define DISABLE_GET_GOLD	TRUE						// إيقاف الحصول على اليانغ من بيع الأغراض أو قتل الوحوش
#define ENABLE_PARTY_STONE
// ### Special Features ###
//////////////////////////////////////////////////////////////////////////

#define ENABLE_PARTY_WAR
#define PARTY_WAR_MAP 410

//////////////////////////////////////////////////////////////////////////
// ### Fix Features ###
#define ENABLE_FLUSH_AT_SHUTDOWN
#define ENABLE_OBSERVER_DAMAGE_FIX
#define ENABLE_WARRIOR_SURA_SKILL_FIX
#define ENABLE_HORSE_FIXES
#define ENABLE_CREAT_CHARACTER_ML_FIX
#define ENABLE_CHAR_NAME_FIX
#define ENABLE_RESETSKLL_FIX
#define ENABLE_SAFEBOX_ML_FIX
#define ENABLE_NEW_CMD_WAIT
#define OPEN_SHOP_ML_FIX
#define ENERGY_GAME_CORE_FIX
#define ENABLE_SAVE_REAL_FIX
#define ENABLE_ITEM_OWNER_FIX
#define ENABLE_FIX_ARROW_CORE
// ### Fix Features ###
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// ### Protections Features ###
#define ENABLE_CHAT_SPAMLIMIT
#define ENABLE_WHISPER_CHAT_SPAMLIMIT
#define INVALID_PLAYER_ID_SPAM_FIX
#define ENABLE_FLOOD_PRETECTION
#define ENABLE_ANTI_CMD_FLOOD
#define ENABLE_SQL_INJECT_CONTROL_ON_QUERY
#define ENABLE_BLOCK_CMD_SHORTCUT
#define __IMPROVED_HANDSHAKE_PROCESS__ 
#define ENABLE_WAIT_HACK_FIX
#define ENABLE_WAIT_HACK_COUNT	4
#define ENABLE_PROTECTION_LOGGING
// ### Protections Features ###
//////////////////////////////////////////////////////////////////////////

//////////////////////////////////////////////////////////////////////////
// ### CommonDefines Systems ###
#define ENABLE_WOLFMAN_CHARACTER
#ifdef ENABLE_WOLFMAN_CHARACTER
#define USE_MOB_BLEEDING_AS_POISON
#define USE_MOB_CLAW_AS_DAGGER
// #define USE_ITEM_BLEEDING_AS_POISON
// #define USE_ITEM_CLAW_AS_DAGGER
#define USE_WOLFMAN_STONES
#define USE_WOLFMAN_BOOKS
#endif

#define ENABLE_PLAYER_PER_ACCOUNT5
#define ENABLE_DICE_SYSTEM
#define ENABLE_EXTEND_INVEN_SYSTEM

#define ENABLE_MOUNT_COSTUME_SYSTEM
#define ENABLE_WEAPON_COSTUME_SYSTEM

// #define ENABLE_MAGIC_REDUCTION_SYSTEM
#ifdef ENABLE_MAGIC_REDUCTION_SYSTEM
// #define USE_MAGIC_REDUCTION_STONES
#endif


/*
	###		New Defines Extended Version		###
*/
// todo : coding GLOBAL GIFT SYSTEM
// if ENABLE_GLOBAL_GIFT is defined, the GMs can use the quest global_gift_management.quest to set a global gift
//#define ENABLE_GLOBAL_GIFT


//#define DISABLE_STOP_RIDING_WHEN_DIE //	if DISABLE_TOP_RIDING_WHEN_DIE is defined , the player does not lose the horse after his death
#define ENABLE_ACCE_SYSTEM //fixed version
#define ENABLE_HIGHLIGHT_NEW_ITEM //if you want to see highlighted a new item when dropped or when exchanged
#define __ENABLE_KILL_EVENT_FIX__ //if you want to fix the 0 exp problem about the when kill lua event (recommended)






/*
	***  Defines To DEBUG  ***
*/
// #define ENABLE_SYSLOG_PACKET_SENT











// ### CommonDefines Systems ###
//////////////////////////////////////////////////////////////////////////

#endif

