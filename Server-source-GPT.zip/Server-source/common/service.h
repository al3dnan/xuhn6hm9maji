#ifndef __INC_SERVICE_H__
#define __INC_SERVICE_H__

#define CHAT_SLOW_MODE

#define _IMPROVED_PACKET_ENCRYPTION_
//#define __AUCTION__
#define __PET_SYSTEM__
#define __UDP_BLOCK__
#endif
#define __TITLE_SYSTEM_YUMA__
#define NEW_CHECK_VERSION 3003010
#define SKILL_COOLTIME_UPDATE
#define __BL_KILL_BAR__