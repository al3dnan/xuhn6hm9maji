typedef struct packet_auction_simple_item_info
{
	BYTE		header;
	BYTE		size;
} TPacketGCAuctionItemSimpleInfo;

