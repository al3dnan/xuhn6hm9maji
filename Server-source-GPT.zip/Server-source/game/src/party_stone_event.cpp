/***********************
#ifdef ENABLE_PARTY_STONE
By CONTROL = True
By Someone else = False
#endif
***********************/
#include "stdafx.h"
#include "utils.h"
#include "char.h"
#include "questmanager.h"
#include "config.h"
#include "locale_service.h"
#include "item_manager.h"
#include "desc_manager.h"
#include "sectree_manager.h"
#include "char_manager.h"
#include "party_stone_event.h"
#include "desc.h"
#include "log.h"
#include "start_position.h"
#include "party.h"
#include "questlua.h"
#include "buffer_manager.h"
#include "db.h"
#include "locale_service.h"
#include "sectree_manager.h"
#include "questpc.h"
#include "quest.h"
#include "affect.h"
LPEVENT partystonespawn = nullptr;
static const std::unordered_set<int> StoneEventMaps = STONE_EVENT_MAPS;

EVENTINFO(partystone_warp_all_to_village_info)
{
	DWORD dwWarpMapIndex;

	partystone_warp_all_to_village_info()
	: dwWarpMapIndex( 0 )
	{
	}
};

struct FWarpAllToVillage
{
	FWarpAllToVillage() {};
	void operator()(LPENTITY ent)
	{
		if (ent->IsType(ENTITY_CHARACTER))
		{
			LPCHARACTER ch = (LPCHARACTER) ent;
			if (ch->IsPC())
			{
				BYTE bEmpire =  ch->GetEmpire();
				if ( bEmpire == 0 )
				{
					sys_err( "Unkonwn Empire %s %d ", ch->GetName(), ch->GetPlayerID() );
					return;
				}

				ch->WarpSet( g_start_position[bEmpire][0], g_start_position[bEmpire][1] );
				ch->Stop();
			}
		}
	}
};

EVENTFUNC(partystone_warp_all_to_village_event)
{
	partystone_warp_all_to_village_info * info = dynamic_cast<partystone_warp_all_to_village_info *>(event->info);

	if ( info == NULL )
	{
		sys_err( "partystone_warp_all_to_village_event> <Factor> Null pointer" );
		return 0;
	}

	LPSECTREE_MAP pSecMap = SECTREE_MANAGER::instance().GetMap( info->dwWarpMapIndex );

	if (NULL != pSecMap)
	{
		FWarpAllToVillage f;
		pSecMap->for_each( f );
	}

	return 0;
}

struct FPurgeMonsters
{
	void operator () (LPENTITY ent)
	{
		if (ent->IsType(ENTITY_CHARACTER))
		{
			LPCHARACTER ch = (LPCHARACTER) ent;

			if (!ch->IsPC() && !ch->IsPet()
#ifdef ENABLE_PRESENT_MOUNT_SYSTEM
				&& !ch->IsMount()
#endif
#if defined(ENABLE_BUFFI_SYSTEM)
				&& !ch->IsBuffNPC()
#endif
			)
			{
				M2_DESTROY_CHARACTER(ch);
			}
		}
	}
};

bool CPartyStoneEvent::Initialize()
{
	m_map_partystone_info.clear();
	m_map_partystone_leaders.clear();
	m_map_partystone_observer.clear();
	event_cancel(&partystonespawn);

	return true;
}
/////////////////////////////////////

bool CPartyStoneEvent::CanHitStone(LPCHARACTER ch, LPCHARACTER victim)
{
	if (!GetTeam(ch)) {
		return false;
	}
	
	if (ch->FindAffect(AFFECT_STONE_TEAM_A))
	{
		if (victim->GetRaceNum() == FIRST_PARTY_STONE_VNUM || victim->GetRaceNum() == FIRST_PARTY_CORE_VNUM) {
			return false; // You Can't Hit Your Own Core Or Stones
		}
	}
	
	if (ch->FindAffect(AFFECT_STONE_TEAM_B)) 
	{
		if (victim->GetRaceNum() == SECOND_PARTY_STONE_VNUM || victim->GetRaceNum() == SECOND_PARTY_CORE_VNUM) {
			return false; // You Can't Hit Your Own Core Or Stones
		}
	}
	
	if (!ch->FindAffect(AFFECT_CORE_TEAM_A) && victim->GetRaceNum() == SECOND_PARTY_CORE_VNUM) {
		return false;
	}
	
	if (!ch->FindAffect(AFFECT_CORE_TEAM_B) && victim->GetRaceNum() == FIRST_PARTY_CORE_VNUM) {
		return false;
	}
	
	return true;
}

void CPartyStoneEvent::RegisterTeamPoints(LPCHARACTER ch, LPCHARACTER victim, int MapIndex)
{
	if (!GetTeam(ch)) {
		return;
	}
	
	if (ch->FindAffect(AFFECT_STONE_TEAM_A) && victim->GetRaceNum() == SECOND_PARTY_STONE_VNUM) 
	{
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			MapInfo& mapInfo = m_map_partystone_info[MapIndex];
			
			if (mapInfo.ATeamPoints == 3) {
				SetTeamCoreEffect(ch, 1);
				SetTeamReachCore(ch, MapIndex);
				SendNoticeMap("�� ����� ���� ����� ������ ������", MapIndex, false);
			}
			else
			{
				SendNoticeMap("�� ����� ��� ����� ������ ������", MapIndex, false);
			}
			mapInfo.ATeamPoints += 1;
			
		}
	}
	if (ch->FindAffect(AFFECT_CORE_TEAM_A) && victim->GetRaceNum() == SECOND_PARTY_CORE_VNUM) 
	{
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			DeclareTheWinnerTeam(ch, 1, MapIndex);
		}
	}
	
	if (ch->FindAffect(AFFECT_STONE_TEAM_B) && victim->GetRaceNum() == FIRST_PARTY_STONE_VNUM) 
	{
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			MapInfo& mapInfo = m_map_partystone_info[MapIndex];
			if (mapInfo.BTeamPoints == 3) {
				SetTeamCoreEffect(ch, 2);
				SetTeamReachCore(ch, MapIndex);
				SendNoticeMap("�� ����� ���� ����� ������ ������", MapIndex, false);
			}
			else
			{
				SendNoticeMap("�� ����� ��� ����� ������ ������", MapIndex, false);
			}
			mapInfo.BTeamPoints += 1;
		}
	}
	if (ch->FindAffect(AFFECT_CORE_TEAM_B) && victim->GetRaceNum() == FIRST_PARTY_CORE_VNUM) 
	{
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			DeclareTheWinnerTeam(ch, 2, MapIndex);
		}
	}
}

void CPartyStoneEvent::InitializeByMap(int MapIndex)
{
	// Clear The Leaders
	auto itFrst = m_map_partystone_leaders.begin();
	while (itFrst != m_map_partystone_leaders.end())
	{
		if (itFrst->second.LeaderMap == MapIndex) {
			itFrst = m_map_partystone_leaders.erase(itFrst);
		}
		else {
			++itFrst;
		}
	}
	
	// Clear The Map
	auto itSec = m_map_partystone_info.begin();
	while (itSec != m_map_partystone_info.end())
	{
		if (itSec->first == MapIndex) {
			itSec = m_map_partystone_info.erase(itSec);
		}
		else {
			++itSec;
		}
	}
}

void CPartyStoneEvent::DeclareTheWinnerTeam(LPCHARACTER ch, BYTE Team, int MapIndex)
{
	
	//Clear maps
	InitializeByMap(MapIndex);
	
	// Notice in map
	if (Team == 1) {
		SendNoticeMap("�� ����� ����� ����� ������� ������", MapIndex, false);
	}
	else {
		SendNoticeMap("�� ����� ����� ����� ������� ������", MapIndex, false);
	}

	// Warp all in 3 sec
	auto warpInfo = AllocEventInfo<partystone_warp_all_to_village_info>();
	warpInfo->dwWarpMapIndex = MapIndex;
	event_create(partystone_warp_all_to_village_event, warpInfo, PASSES_PER_SEC(5));
}


void CPartyStoneEvent::SetTeamReachCore(LPCHARACTER ch, long MapIndex)
{
	if (!ch->GetParty())
		return;

	DWORD lpid = ch->GetParty()->GetLeaderPID();
	for (auto& map : m_map_partystone_leaders)
	{
		if (lpid == map.first)
		{
			if (map.second.LeaderMap == MapIndex)
			{
				map.second.ReachTheCore = true;
			} 
		} 
	} 
}

bool CPartyStoneEvent::isReachCore(LPCHARACTER ch)
{
	if (!ch->GetParty())
		return false;

	DWORD lpid = ch->GetParty()->GetLeaderPID();
	for (auto& map : m_map_partystone_leaders)
	{
		if (lpid == map.first && map.second.ReachTheCore)
		{
			return true;
		} 
	}
	
	return false;
}

BYTE CPartyStoneEvent::GetTeam(LPCHARACTER ch)
{
	if (!ch->GetParty())
		return false;

	DWORD lpid = ch->GetParty()->GetLeaderPID();
	for (auto& map : m_map_partystone_leaders)
	{
		if (lpid == map.first)
		{
			return map.second.LeaderTeam; // 1 & 2
		} 
	}
	
	return false;
}

bool CPartyStoneEvent::IsStoneEventMap(long Mapindex)
{
	if (StoneEventMaps.count(Mapindex) > 0) {
		return true;
	}
	return false;
}

void CPartyStoneEvent::OnLogin(LPCHARACTER ch)
{
	long mapIndex = ch->GetMapIndex();
	if (IsStoneEventMap(mapIndex)) {
		if (IsObserver(ch)) {
			ch->SetObserverMode(true);
			return;
		}
		if (GetTeam(ch) > 0) {
			return;
		}
		if (ch->GetGMLevel() == GM_IMPLEMENTOR) { // No Kick For Implementor !!
			return;
		}
		
		BYTE bEmpire = ch->GetEmpire();
		ch->WarpSet( g_start_position[bEmpire][0], g_start_position[bEmpire][1]);
		ch->Stop();
	}
	else
	{
		if (IsObserver(ch)) {
			RemoveObserver(ch);
		}
	}
}

/********************************** SpawnStones ***************************************/

EVENTINFO(TMainEventCheck)
{
	long MapIndex;
	
	TMainEventCheck() 
	: MapIndex( 0 )
	{}
	
} ;

EVENTFUNC(partystone_spawn_event)
{
	TMainEventCheck * info = dynamic_cast<TMainEventCheck *>(  event->info );
	if ( info == NULL )
	{
		sys_err( "attack_event> <Factor> Null pointer" );
		return 0;
	}
	
	CPartyStoneEvent::instance().SpawnPartyStones(info->MapIndex);

	return 0;
}

int CPartyStoneEvent::BasePostionsX(BYTE Map)
{
	int BasePostionTable[] = 
	{
		435200, 435200, 435200, 435200, 435200,
		486400, 486400, 486400, 486400, 486400
	};
	return BasePostionTable[Map];
}
int CPartyStoneEvent::BasePostionsY(BYTE Map)
{
	int BasePostionTable[] = 
	{
		486400, 537600, 588800, 640000, 691200,
		486400, 537600, 588800, 640000, 691200
	};
	return BasePostionTable[Map];
}

void CPartyStoneEvent::SpawnPartyStones(int MapIndex)
{
	int StoneCordsX [] =  {28300, 22800, 20100, 31100, 25600, 28400, 31000, 23000, 20200, 25600};
	int StoneCordsY [] =  {20700, 20700, 21600, 21500, 18200, 29700, 28800, 29700, 28700, 32000};
	int mapNumber = MapIndex - MAIN_STONE_MAP_INDEX;

	CharacterVectorInteractor i;

	const std::vector<std::pair<DWORD, std::pair<int, int>>> STONES = {
		{ FIRST_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[0], BasePostionsY(mapNumber) + StoneCordsY[0] } },
		{ FIRST_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[1], BasePostionsY(mapNumber) + StoneCordsY[1] } },
		{ FIRST_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[2], BasePostionsY(mapNumber) + StoneCordsY[2] } },
		{ FIRST_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[3], BasePostionsY(mapNumber) + StoneCordsY[3] } },
		{ FIRST_PARTY_CORE_VNUM,  { BasePostionsX(mapNumber) + StoneCordsX[4], BasePostionsY(mapNumber) + StoneCordsY[4] } },
		
		{ SECOND_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[5], BasePostionsY(mapNumber) + StoneCordsY[5] } },
		{ SECOND_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[6], BasePostionsY(mapNumber) + StoneCordsY[6] } },
		{ SECOND_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[7], BasePostionsY(mapNumber) + StoneCordsY[7] } },
		{ SECOND_PARTY_STONE_VNUM, { BasePostionsX(mapNumber) + StoneCordsX[8], BasePostionsY(mapNumber) + StoneCordsY[8] } },
		{ SECOND_PARTY_CORE_VNUM,  { BasePostionsX(mapNumber) + StoneCordsX[9], BasePostionsY(mapNumber) + StoneCordsY[9] } }
	};

	for (const auto& stone : STONES)
	{
		if (!CHARACTER_MANAGER::instance().GetCharactersByRaceNum(stone.first, i))
		{
			CHARACTER_MANAGER::instance().SpawnMob(stone.first, MapIndex, stone.second.first, stone.second.second, 0, false, -1);
		}
	}
}

void CPartyStoneEvent::StartSpawnTimer(int MapIndex)
{
	auto checkInfo = AllocEventInfo<TMainEventCheck>();
	checkInfo->MapIndex = MapIndex;
	partystonespawn = event_create(partystone_spawn_event, checkInfo, PASSES_PER_SEC(10)); /* Spawn After 5 Seconds From Joining */

}

void CPartyStoneEvent::PurgeMap(int MapIndex)
{
	if (auto sectreeMap = SECTREE_MANAGER::instance().GetMap(MapIndex))
	{
		FPurgeMonsters purgeFunc;
		sectreeMap->for_each(purgeFunc);
	}
}
/********************************** SpawnStones ***************************************/

/********************************** GiveCoreAffect ***************************************/
/* This is :
	To Give The Team The Core Affect When They Destroy 
	All The Enemy Normal Stones So They Can Destroy The Core
*/
struct FSetMembersAffect {
	BYTE Team;
	static const int NumEffects = 2;
	int EffectTable[NumEffects];
	int AffectTable[NumEffects];
	
	FSetMembersAffect(BYTE& Affect) : Team(Affect) {
		EffectTable[0] = AFFECT_CORE_TEAM_A;
		EffectTable[1] = AFFECT_CORE_TEAM_B;
		AffectTable[0] = AFF_CORE_A;
		AffectTable[1] = AFF_CORE_B;
	}
	
	void operator()(CHARACTER* ch) {
		if (!ch->IsPC())
			return;
		
		ch->AddAffect(EffectTable[Team - 1], POINT_NONE, 0, AffectTable[Team - 1], INFINITE_AFFECT_DURATION, 0, true, true);
	}
};

void CPartyStoneEvent::SetTeamCoreEffect(CHARACTER* ch, BYTE Team) {
	FSetMembersAffect f(Team);
	
	if (ch->GetParty()) {
		ch->GetParty()->ForEachOnlineMember(f);
	} else {
		f(ch);
	}
}
/********************************** GiveCoreAffect ***************************************/

/********************************** LeaderRegistration ***************************************/
/* This is :
	1- To Give The Team Affect When They Join/Rejoin
	2- To Kick The Old Team Members If They Try To Rejoin
*/
bool CPartyStoneEvent::StonePartyRegister(LPCHARACTER ch, int MapIndex)
{
	BYTE Team = 0;
	if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
	{
		MapInfo& mapInfo = m_map_partystone_info[MapIndex];
		
		if (mapInfo.EventStatus == 2) {
			/* This Map Already Full !!*/
			return false;
		}

		if (mapInfo.EventStatus == 1)
		{
			mapInfo.EventStatus += 1;
			StartSpawnTimer(MapIndex);
			Team = 2;
		}
	}
	else
	{
		MapInfo mapInfo;
		mapInfo.ATeamPoints = 0;
		mapInfo.BTeamPoints = 0;
		mapInfo.EventStatus = 1;
		m_map_partystone_info[MapIndex] = mapInfo;
		Team = 1;
		PurgeMap(MapIndex);
	}
	
	SetStonePartyLeader(ch, MapIndex, Team);
	UpdateEventInfo();
	return true;
}

BYTE CPartyStoneEvent::GetStonePartyStatus(int MapIndex)
{
	if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end()) {
		MapInfo& mapInfo = m_map_partystone_info[MapIndex];
		return mapInfo.EventStatus;
	}
	return 0;
}

void CPartyStoneEvent::SetStonePartyLeader(LPCHARACTER ch, long mapindex, BYTE Team)
{
	LeaderInfo leader;
	leader.LeaderTeam = Team;
	leader.LeaderMap = mapindex;
	leader.ReachTheCore = false;
	m_map_partystone_leaders[ch->GetPlayerID()] = leader;
}

/********************************** LeaderRegistration ***************************************/

/********************************** Teleport ***************************************/
struct FWarpToPosition
{
	long lMapIndex;
	long x;
	long y;
	FWarpToPosition(long lMapIndex, long x, long y)
		: lMapIndex(lMapIndex), x(x), y(y)
		{}

	void operator()(LPENTITY ent)
	{
		if (!ent->IsType(ENTITY_CHARACTER)) {
			return;
		}
		LPCHARACTER ch = (LPCHARACTER)ent;
		if (!ch->IsPC()) {
			return;
		}
		if (ch->GetMapIndex() == lMapIndex)
		{
			ch->Show(lMapIndex, x, y, 0);
			ch->Stop();
		}
		else
		{
			ch->WarpSet(x,y,lMapIndex);
			ch->Stop();
		}
	}
};
void CPartyStoneEvent::PartyStoneTeleport(LPPARTY pParty, long lFromMapIndex, long MapIndex, int x, int y)
{

	LPSECTREE_MAP pMap = SECTREE_MANAGER::instance().GetMap(lFromMapIndex);
	LPSECTREE_MAP qMap = SECTREE_MANAGER::instance().GetMap(MapIndex);

	if (!pMap || !qMap)
	{
		sys_err("cannot find map by index %d %d", lFromMapIndex,MapIndex);
		return;
	}

	FWarpToPosition f(MapIndex, x, y);

	pParty->ForEachOnMapMember(f, lFromMapIndex);
}
/********************************** Teleport ***************************************/

/********************************** ClearEvent ***************************************/
void CPartyStoneEvent::ClearEvent(BYTE Room)
{
	// Clear the map
	long ErasedMap = MAIN_STONE_MAP_INDEX + Room;
	InitializeByMap(ErasedMap);
	
	// Warp all in 3 sec
	auto warpInfo = AllocEventInfo<partystone_warp_all_to_village_info>();
	warpInfo->dwWarpMapIndex = ErasedMap;
	event_create(partystone_warp_all_to_village_event, warpInfo, PASSES_PER_SEC(5));
	
	// Purge All Metins
	PurgeMap(ErasedMap);
	
	UpdateEventInfo();
}
/********************************** ClearEvent ***************************************/

/********************************** GetInfo ***************************************/
void CPartyStoneEvent::SendEventInfo(LPCHARACTER ch)
{
	unsigned char MaxMapIndex = 10;
	std::vector<unsigned char> MapStatus;
	for (unsigned char i = 0; i < MaxMapIndex; i++)
	{
		long MapIndex = MAIN_STONE_MAP_INDEX + i;
		
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			MapInfo& mapInfo = m_map_partystone_info[MapIndex];
			
			MapStatus.push_back(mapInfo.EventStatus);
		}
		else
		{
			MapStatus.push_back(0);
		}
	}
	
	std::string chatMessage = "stone_status_info ";
	for (unsigned char i = 0; i < MapStatus.size(); i++) {
		chatMessage += std::to_string(MapStatus[i]);
		if (i != MapStatus.size() - 1) {
			chatMessage += " ";
		}
	}
	ch->ChatPacket(CHAT_TYPE_COMMAND, chatMessage.c_str());
	MapStatus.clear();
}

void CPartyStoneEvent::UpdateEventInfo()
{
	unsigned char MaxMapIndex = 10;
	std::vector<unsigned char> MapStatus;
	for (unsigned char i = 0; i < MaxMapIndex; i++)
	{
		long MapIndex = MAIN_STONE_MAP_INDEX + i;
		
		if (m_map_partystone_info.find(MapIndex) != m_map_partystone_info.end())
		{
			MapInfo& mapInfo = m_map_partystone_info[MapIndex];
			
			MapStatus.push_back(mapInfo.EventStatus);
		}
		else
		{
			MapStatus.push_back(0);
		}
	}
	
	std::string chatMessage = "stone_status_update ";
	for (unsigned char i = 0; i < MapStatus.size(); i++) {
		chatMessage += std::to_string(MapStatus[i]);
		if (i != MapStatus.size() - 1) {
			chatMessage += " ";
		}
	}
	
	for (const auto& desc : DESC_MANAGER::instance().GetClientSet()) /* Send Join Button To All Players */
	{
		auto character = desc->GetCharacter();
		if (character)
		{
			if ((1 == g_bChannel ) && (character->GetMapIndex() == 1 || character->GetMapIndex() == 21 || character->GetMapIndex() == 41)) {
				character->ChatPacket(CHAT_TYPE_COMMAND, chatMessage.c_str());
			}
		}
	}
	
	MapStatus.clear();
}
/********************************** GetInfo ***************************************/

/********************************** Observer ***************************************/
void CPartyStoneEvent::SetObserver(LPCHARACTER ch)
{
	DWORD pid = ch->GetPlayerID();
	m_map_partystone_observer.insert(std::make_pair(pid, pid));
}

void CPartyStoneEvent::RemoveObserver(LPCHARACTER ch)
{
	DWORD pid = ch->GetPlayerID();
	auto it = m_map_partystone_observer.find(pid);
	if (it == m_map_partystone_observer.end()) {
		return;
	}
	m_map_partystone_observer.erase(pid);
}

bool CPartyStoneEvent::IsObserver(LPCHARACTER ch)
{
	if (m_map_partystone_observer.empty()) {
		return false;
	}
	
	itertype(m_map_partystone_observer) iter = m_map_partystone_observer.begin();
	for (; iter != m_map_partystone_observer.end(); ++iter) 
	{
		if (iter->first == ch->GetPlayerID()) {
			return true;
		}
	}

	return false;
}
/********************************** Observer ***************************************/
	