
#define FIRST_PARTY_CORE_VNUM 9601
#define FIRST_PARTY_STONE_VNUM 9602

#define SECOND_PARTY_CORE_VNUM 9603
#define SECOND_PARTY_STONE_VNUM 9604

#define MAX_PLAYER_COUNT 5
#define MAIN_STONE_MAP_INDEX 450

static const std::unordered_set<int> STONE_EVENT_MAPS = 
{ 
	450, 451 , 452 , 453 , 454,
	455, 456 , 457 , 458 , 459
};

struct MapInfo { // The Key Is Going To Be The MapIndex
    BYTE ATeamPoints; // When The Team A Join Add The Points - Chqnges Based On The Effect On The Player
    BYTE BTeamPoints; // When The Team B Join Add The Points - Chqnges Based On The Effect On The Player
	BYTE EventStatus; /*
		0 : No Teams
		1 : Queue
		2 : Full - No One Can Join
		The Status Is The Thing That Arrange
		The Players Effects And Stones And Postions
		And Wether The Map Is Joinable Or Not
	*/
};

struct LeaderInfo {
    BYTE LeaderTeam;	// 1 & 2
    long LeaderMap;		//
	bool ReachTheCore;	//
};

class CPartyStoneEvent : public singleton<CPartyStoneEvent>
{
	private :
		std::map<int, MapInfo> m_map_partystone_info;
		std::map<int, LeaderInfo> m_map_partystone_leaders;
		std::map<DWORD, DWORD> m_map_partystone_observer;
		

	public :
		bool 	Initialize();
		bool 	CanHitStone(LPCHARACTER ch, LPCHARACTER victim);
		void 	RegisterTeamPoints(LPCHARACTER ch, LPCHARACTER victim, int MapIndex);
		bool 	isReachCore(LPCHARACTER ch);
		BYTE 	GetTeam(LPCHARACTER ch);
		void 	OnLogin(LPCHARACTER ch);
		void 	PartyStoneTeleport(LPPARTY pParty, long lFromMapIndex, long MapIndex, int x, int y);
		void 	SpawnPartyStones(int MapIndex);
		bool 	StonePartyRegister(LPCHARACTER ch, int MapIndex);
		int 	BasePostionsX(BYTE Map);
		int 	BasePostionsY(BYTE Map);
		bool 	IsStoneEventMap(long Mapindex);
		void 	InitializeByMap(int MapIndex);
		void 	ClearEvent(BYTE Room);
		void 	SendEventInfo(LPCHARACTER ch);
		void 	SetObserver(LPCHARACTER ch);
		BYTE 	GetStonePartyStatus(int MapIndex);

	private:
		void 	DeclareTheWinnerTeam(LPCHARACTER ch, BYTE Team, int MapIndex);
		void 	SetTeamReachCore(LPCHARACTER ch, long MapIndex);
		void 	StartSpawnTimer(int MapIndex);
		void 	SetTeamCoreEffect(CHARACTER* ch, BYTE Team);
		void 	SetStonePartyLeader(LPCHARACTER ch, long mapindex, BYTE Team);
		void 	PurgeMap(int MapIndex);
		void 	UpdateEventInfo();
		void 	RemoveObserver(LPCHARACTER ch);
		bool 	IsObserver(LPCHARACTER ch);
		

};