/***********************
#ifdef ENABLE_PARTY_WAR
By CONTROL = True
By Someone else = False
#endif
***********************/
#include "stdafx.h"
#include "utils.h"
#include "char.h"
#include "questmanager.h"
#include "config.h"
#include "locale_service.h"
#include "item_manager.h"
#include "desc_manager.h"
#include "sectree_manager.h"
#include "char_manager.h"
#include "party_war_event.h"
#include "desc.h"
#include "log.h"
#include "start_position.h"
#include "party.h"
#include "questlua.h"
#include "buffer_manager.h"
#include "db.h"
#include "locale_service.h"
#include "sectree_manager.h"
#include "questpc.h"
#include "quest.h"

const int positions[4][2] = {
    {18000, 12700},
    {7400, 12700},
    {12600, 18000},
    {12600, 7300}
};


EVENTINFO(partywar_warp_all_to_village_info)
{
	DWORD dwWarpMapIndex;

	partywar_warp_all_to_village_info()
	: dwWarpMapIndex( 0 )
	{
	}
};

struct FWarpAllToVillage
{
	FWarpAllToVillage() {};
	void operator()(LPENTITY ent)
	{
		if (ent->IsType(ENTITY_CHARACTER))
		{
			LPCHARACTER ch = (LPCHARACTER) ent;
			if (ch->IsPC())
			{
				BYTE bEmpire =  ch->GetEmpire();
				if ( bEmpire == 0 )
				{
					sys_err( "Unkonwn Empire %s %d ", ch->GetName(), ch->GetPlayerID() );
					return;
				}

				ch->WarpSet( g_start_position[bEmpire][0], g_start_position[bEmpire][1] );
				ch->Stop();
			}
		}
	}
};

EVENTFUNC(partywar_warp_all_to_village_event)
{
	partywar_warp_all_to_village_info * info = dynamic_cast<partywar_warp_all_to_village_info *>(event->info);

	if ( info == NULL )
	{
		sys_err( "partywar_warp_all_to_village_event> <Factor> Null pointer" );
		return 0;
	}

	LPSECTREE_MAP pSecMap = SECTREE_MANAGER::instance().GetMap( info->dwWarpMapIndex );

	if (NULL != pSecMap)
	{
		FWarpAllToVillage f;
		pSecMap->for_each( f );
	}

	return 0;
}

bool CPartyWarEvent::Initialize()
{
	m_map_partywarleader.clear();
	m_map_partywarmember.clear();
	m_partywar_type.clear();
	m_TimerMap.clear();

	return true;
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

void CPartyWarEvent::EnterPartyWarLeader(LPCHARACTER pkChar)
{
	DWORD pid = pkChar->GetPlayerID();
	m_map_partywarleader.insert(std::make_pair(pid, pid));
}

void CPartyWarEvent::RemovePartyWarLeader(LPCHARACTER pkChar)
{
	DWORD pid = pkChar->GetPlayerID();
	
	auto it = m_map_partywarleader.find(pid);
	if (it == m_map_partywarleader.end())
	{
		return;
	}
	
	m_map_partywarleader.erase(pid);
}


bool CPartyWarEvent::IsPartyWarLeader(LPCHARACTER pkChar)
{
	itertype(m_map_partywarleader) iter = m_map_partywarleader.begin();

	for (; iter != m_map_partywarleader.end(); ++iter)
	{
		if (iter->second == pkChar->GetPlayerID())
		{
			return true;
		}
	}

	return false;
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////

void CPartyWarEvent::EnterPartyWarMember(LPCHARACTER pkChar)
{
	if (!pkChar->GetParty())
		return;
	
	DWORD pid = pkChar->GetPlayerID();
	DWORD lpid = pkChar->GetParty()->GetLeaderPID();
	
	m_map_partywarmember.insert(std::make_pair(pid, lpid));
}

void CPartyWarEvent::RemovePartyWarMember(LPCHARACTER pkChar)
{
	DWORD pid = pkChar->GetPlayerID();
	
	auto it = m_map_partywarmember.find(pid);
	if (it == m_map_partywarmember.end())
	{
		return;
	}
	m_map_partywarmember.erase(pid);
}


bool CPartyWarEvent::IsPartyWarMember(LPCHARACTER pkChar)
{
	itertype(m_map_partywarmember) iter = m_map_partywarmember.begin();

	for (; iter != m_map_partywarmember.end(); ++iter)
	{
		if (iter->first == pkChar->GetPlayerID())
		{
			return true;
		}
	}

	return false;
}

bool CPartyWarEvent::IsPartyWarWinner()
{
    if (m_map_partywarmember.empty()) {
        return false;
    }

    int firstVal = m_map_partywarmember.begin()->second;

    for (auto it = m_map_partywarmember.begin(); it != m_map_partywarmember.end(); ++it) {
        //const auto& pid = it->first;
        const auto& val = it->second;

        if (val != firstVal) {
            return false;
        }
    }

    return true;
}

bool CPartyWarEvent::HasPartyWarLeader(LPCHARACTER pkChar)
{
    if (!pkChar->GetParty())
        return false;

    DWORD lpid = pkChar->GetParty()->GetLeaderPID();

    auto it = m_map_partywarleader.find(lpid);
    if (it == m_map_partywarleader.end())
    {
        return false;
    }
    return true;
}


void CPartyWarEvent::OnPlayerOut(LPCHARACTER pkChar)
{
	const int leadersCount = GetPartyWarLeadersCount();
	const int remainingTime = static_cast<int>(GetRemainingTime("partywar_timer"));
	const DWORD PARTY_WAR_MAP_INDEX = PARTY_WAR_MAP;
	const DWORD TELEPORT_DELAY_SEC = 5;
	
	if (IsPartyWarMember(pkChar))
	{	
		if (GetEventType("partywar_type") == 1)
		{
			if (pkChar->GetParty() && pkChar->GetParty()->GetLeaderPID() == pkChar->GetPlayerID())
			{
				RemovePartyWarLeader(pkChar);
				RemovePartyWarMember(pkChar);

				if (leadersCount == 2 && remainingTime <= 0)
				{
					PartySetReward();
					char buf[100];
					snprintf(buf, sizeof(buf), LC_TEXT("partywar: 17"));
					SendNotice(buf);
					auto warpInfo = AllocEventInfo<partywar_warp_all_to_village_info>();
					warpInfo->dwWarpMapIndex = PARTY_WAR_MAP_INDEX;
					event_create(partywar_warp_all_to_village_event, warpInfo, PASSES_PER_SEC(TELEPORT_DELAY_SEC)); /* Warp All Players Home */
				}
				
				BYTE index = number(0, 3);
	
				PartyWarJoin(pkChar->GetParty(), pkChar->GetMapIndex(), PARTY_WAR_MAP, 307200 + positions[index][0], 1561600 + positions[index][1]);
			}
		}
		else if (GetEventType("partywar_type") == 2)
		{

			RemovePartyWarMember(pkChar);
			
			if (IsPartyWarWinner() && remainingTime <= 0)
			{
				PartySetReward();
				char buf[100];
				snprintf(buf, sizeof(buf), LC_TEXT("partywar: 17"));
				SendNotice(buf);
				auto warpInfo = AllocEventInfo<partywar_warp_all_to_village_info>();
				warpInfo->dwWarpMapIndex = PARTY_WAR_MAP_INDEX;
				event_create(partywar_warp_all_to_village_event, warpInfo, PASSES_PER_SEC(TELEPORT_DELAY_SEC)); /* Warp All Players Home */
			}

			BYTE index = number(0, 3);
			pkChar->WarpSet(307200 + positions[index][0], 1561600 + positions[index][1]);
			pkChar->Stop();
		}
	}
}


void CPartyWarEvent::OnLogin(LPCHARACTER pkChar)
{
	
	if (pkChar->GetMapIndex() == PARTY_WAR_MAP && GetEventType("partywar_type") == 0)
	{
		if (pkChar->GetGMLevel() == GM_IMPLEMENTOR) { // No Kick For Implementor !!
			return;
		}
		
		BYTE bEmpire =  pkChar->GetEmpire();
		if ( bEmpire == 0 )
		{
			sys_err( "Unkonwn Empire %s %d ", pkChar->GetName(), pkChar->GetPlayerID() );
			return;
		}
		pkChar->WarpSet( g_start_position[bEmpire][0], g_start_position[bEmpire][1] );
		pkChar->Stop();
	}
	
	const int timeLeft = GetRemainingTime("partywar_timer");
	if (timeLeft > 0) { // Send The Timer
		if (pkChar->GetMapIndex() == PARTY_WAR_MAP) {
			pkChar->ChatPacket(CHAT_TYPE_COMMAND, "%s %d","partywar_time", timeLeft);
		}
		else {
			if ((1 == g_bChannel ) && (pkChar->GetMapIndex() == 1 || pkChar->GetMapIndex() == 21 || pkChar->GetMapIndex() == 41)) {
				pkChar->ChatPacket(CHAT_TYPE_COMMAND, "%s %d","partywar_button", timeLeft);
			}
		}
	}
	
	if (pkChar->GetMapIndex() == PARTY_WAR_MAP && IsPartyWarMember(pkChar))
	{
		if (GetEventType("partywar_type") == 1)
		{
			if (pkChar->GetParty())
			{
				if (pkChar->GetParty()->GetLeaderPID() == pkChar->GetPlayerID()) { // He Is The Leader
					return;
				}
				if (HasPartyWarLeader(pkChar)) { // He Got A Leader
					return;
				}
			}
			
			RemovePartyWarMember(pkChar);

			BYTE index = number(0, 3);
			pkChar->WarpSet(153600 + positions[index][0], 1971200 + positions[index][1]);
			pkChar->Stop();
			pkChar->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("partywar: 11"));
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////
////////////////////////////////////////////////////////////////////////////////////////




LPEVENT partywarcheck = NULL;

EVENTINFO(TMainEventCheck)
{
	int None;
	
	TMainEventCheck() 
	: None( 0 )
	{}
	
} ;

EVENTFUNC(partywar_check_event)
{
	TMainEventCheck * info = dynamic_cast<TMainEventCheck *>(  event->info );
	if ( info == NULL )
	{
		sys_err( "attack_event> <Factor> Null pointer" );
		return 0;
	}
	
	char buf[100];
	if (CPartyWarEvent::instance().GetPartyWarLeadersCount() < 2)
	{
		const DWORD PARTY_WAR_MAP_INDEX = PARTY_WAR_MAP;
		const DWORD TELEPORT_DELAY_SEC = 5;

		snprintf(buf, sizeof(buf), LC_TEXT("partywar: 18"));

		DWORD mapIndex = PARTY_WAR_MAP_INDEX;
		CPartyWarEvent::instance().Initialize();
		partywar_warp_all_to_village_info* info = AllocEventInfo<partywar_warp_all_to_village_info>();
		info->dwWarpMapIndex = mapIndex;
		event_create(partywar_warp_all_to_village_event, info, PASSES_PER_SEC(TELEPORT_DELAY_SEC));
		SendNoticeMap(LC_TEXT("partywar: 13"), mapIndex, false);
	}
	else
	{
		snprintf(buf, sizeof(buf), LC_TEXT("partywar: 19"));
	}
	SendNotice(buf);

	return 0;
}

void CPartyWarEvent::StartPartyWarEvent(LPCHARACTER ch, DWORD eventType, DWORD eventDuration)
{
    constexpr DWORD SECONDS_PER_MINUTE = 60;
    constexpr DWORD TELEPORT_DELAY_SEC = 5;
    constexpr DWORD EVENT_CLOSED = 0;
    constexpr DWORD PARTY_WAR_MAP_INDEX = PARTY_WAR_MAP;

    eventDuration *= SECONDS_PER_MINUTE;

    if (eventType == EVENT_CLOSED) /* Closing the event */
    {
        ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("partywar: 12"));

        Initialize(); /* Clear All Maps */

        auto warpInfo = AllocEventInfo<partywar_warp_all_to_village_info>();
        warpInfo->dwWarpMapIndex = PARTY_WAR_MAP_INDEX;
        event_create(partywar_warp_all_to_village_event, warpInfo, PASSES_PER_SEC(TELEPORT_DELAY_SEC)); /* Warp All Players Home */

        SendNoticeMap(LC_TEXT("partywar: 13"), PARTY_WAR_MAP_INDEX, false); /* Send Closing Notice To All Players In Map */

        if (partywarcheck)/* Remove Old Timer If Exist */
            event_cancel(&partywarcheck);

        for (const auto& desc : DESC_MANAGER::instance().GetClientSet()) /* Remove Join Button From All Players */
		{
			auto character = desc->GetCharacter();
			if (character && character->GetMapIndex() != PARTY_WAR_MAP_INDEX)
			{
				character->ChatPacket(CHAT_TYPE_COMMAND, "partywar_button %d", 0);
			}
		}
    }
    else /* Opening the event */
    {
		if (GetEventType("partywar_type") != 0)
		{
			ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("partywar: 20"));
			return;
		}
		
		StartEvent("partywar_type", eventType);/* Set Event */
        StartTimer("partywar_timer", eventDuration);/* Start Event Timer */
        ch->ChatPacket(CHAT_TYPE_INFO, LC_TEXT("partywar: 14"));

        if (partywarcheck)/* Remove Old Timer If Exist */
            event_cancel(&partywarcheck);

        auto checkInfo = AllocEventInfo<TMainEventCheck>();
        checkInfo->None = 0;
        partywarcheck = event_create(partywar_check_event, checkInfo, PASSES_PER_SEC(eventDuration));/* Start Event Timer */

        char buf[100]; /* Send Notice To All Players */
        if (eventType == 1)
            snprintf(buf, sizeof(buf), LC_TEXT("partywar: 15 :%d"), eventDuration / SECONDS_PER_MINUTE);
        else
            snprintf(buf, sizeof(buf), LC_TEXT("partywar: 16 :%d"), eventDuration / SECONDS_PER_MINUTE);
        SendNotice(buf);
		
		for (const auto& desc : DESC_MANAGER::instance().GetClientSet()) /* Send Join Button To All Players */
		{
			auto character = desc->GetCharacter();
			if (character && character->GetMapIndex() != PARTY_WAR_MAP_INDEX)
			{
				if ((1 == g_bChannel ) && (character->GetMapIndex() == 1 || character->GetMapIndex() == 21 || character->GetMapIndex() == 41)) {
					character->ChatPacket(CHAT_TYPE_COMMAND, "partywar_button %d", eventDuration);
				}
			}
		}
    }
}

void CPartyWarEvent::StartEvent(const std::string& event, DWORD type)
{
	m_partywar_type[event] = type;
}

DWORD CPartyWarEvent::GetEventType(const std::string& event)
{
	auto it = m_partywar_type.find(event);

	if (it == m_partywar_type.end())
	{
		return 0;
	}

	DWORD type = it->second;

	return type;
}

void CPartyWarEvent::StartTimer(const std::string& name, DWORD duration)
{
	m_TimerMap[name] = get_global_time() + duration;
}

DWORD CPartyWarEvent::GetRemainingTime(const std::string& name)
{
	auto it = m_TimerMap.find(name);
	if (it == m_TimerMap.end()) {
		return 0;
	}

	DWORD time = it->second - get_global_time();
	if (time < 0) {
		return 0; // No -time
	}
	
	return time;
}

struct FWarpToPosition
{
	long lMapIndex;
	long x;
	long y;
	FWarpToPosition(long lMapIndex, long x, long y)
		: lMapIndex(lMapIndex), x(x), y(y)
		{}

	void operator()(LPENTITY ent)
	{
		if (!ent->IsType(ENTITY_CHARACTER)) {
			return;
		}
		LPCHARACTER ch = (LPCHARACTER)ent;
		if (!ch->IsPC()) {
			return;
		}
		if (ch->GetMapIndex() == lMapIndex)
		{
			ch->Show(lMapIndex, x, y, 0);
			ch->Stop();
		}
		else
		{
			ch->WarpSet(x,y,lMapIndex);
			ch->Stop();
		}
	}
};
	
struct FSetMembers
{

	void operator() (CHARACTER* ch)
	{
		if (!ch->IsPC())
			return;

		CPartyWarEvent::instance().EnterPartyWarMember(ch);
	}
};

void CPartyWarEvent::PartySetMembers(CHARACTER* ch)
{
	FSetMembers f;

	//if (GetEventType("partywar_type") == 2)
	EnterPartyWarLeader(ch); // SetLeader
	
	if (ch->GetParty())
	{
		ch->GetParty()->ForEachOnlineMember(f); // SetMembers
	}
	else
	{
		f(ch);
	}
}
	
void CPartyWarEvent::PartyWarJoin(LPPARTY pParty, long lFromMapIndex, long MapIndex, int x, int y)
{

	LPSECTREE_MAP pMap = SECTREE_MANAGER::instance().GetMap(lFromMapIndex);
	LPSECTREE_MAP qMap = SECTREE_MANAGER::instance().GetMap(MapIndex);

	if (!pMap || !qMap)
	{
		sys_err("cannot find map by index %d %d", lFromMapIndex,MapIndex);
		return;
	}

	FWarpToPosition f(MapIndex, x, y);

	pParty->ForEachOnMapMember(f, lFromMapIndex);
}

struct FMembersReward
{
	DWORD dwVnum; // New member variable to store dwVnum

	FMembersReward(DWORD vnum) : dwVnum(vnum) {} // Constructor to initialize dwVnum

	void operator()(CHARACTER* ch)
	{
		if (!ch->IsPC())
			return;

		CPartyWarEvent::instance().GiveReward(ch, dwVnum); // Pass dwVnum as a parameter
	}
};

void CPartyWarEvent::PartySetReward()
{
	DWORD dwVnum = quest::CQuestManager::instance().GetEventFlag("partywar_reward"); // Get dwVnum once
	FMembersReward f(dwVnum); // Create FMembersReward object with dwVnum

	for (itertype(m_map_partywarmember) iter = m_map_partywarmember.begin(); iter != m_map_partywarmember.end(); ++iter)
	{
		LPCHARACTER ch = CHARACTER_MANAGER::Instance().FindByPID(iter->first);
		if (ch && ch->GetDesc())
		{
			if (ch->GetParty())
			{
				ch->GetParty()->ForEachOnlineMember(f);
			}
			else
			{
				f(ch);
			}
			break; // Exit the loop after processing the first valid member
		}
	}

	Initialize(); // Clear All Maps
}

void CPartyWarEvent::GiveReward(LPCHARACTER ch, DWORD dwVnum) // Accept dwVnum as a parameter
{
	if (!ch || !ch->GetDesc())
		return;

	DWORD icount = 1;
	sys_log(0, "QUEST [award] item %d to login %s", dwVnum, ch->GetDesc()->GetAccountTable().login);
	//DBManager::instance().Query("INSERT INTO item_award (login, vnum, count, given_time, why, mall) VALUES( '%s', %d, %d, now(), '%s', 1 )", ch->GetDesc()->GetAccountTable().login, dwVnum, icount, "PartyWar");
	ch->AutoGiveItem(dwVnum, icount);
}

	