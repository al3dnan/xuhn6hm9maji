/***********************
#ifdef ENABLE_PARTY_WAR
By CONTROL = True
By Someone else = False
#endif
***********************/
	
class CPartyWarEvent : public singleton<CPartyWarEvent>
{
	private :
		std::map<DWORD, DWORD> m_map_partywarleader;
		std::map<DWORD, DWORD> m_map_partywarmember;
		std::map<std::string, DWORD> m_partywar_type;
        std::map<std::string, DWORD> m_TimerMap;
		

	public :
		/*General*/
		bool 			Initialize();
		
		/*Leaders*/
		bool			IsPartyWarLeader(LPCHARACTER pkChar);
		DWORD 			GetPartyWarLeadersCount() { return m_map_partywarleader.size(); }
		
		/*Members*/
		void			EnterPartyWarMember(LPCHARACTER pkChar);
		bool			IsPartyWarMember(LPCHARACTER pkChar);
		void 			OnPlayerOut(LPCHARACTER pkChar);
		void 			OnLogin(LPCHARACTER pkChar);
		void 			GiveReward(LPCHARACTER ch, DWORD dwVnum);
		
		/*Event*/
		void 			PartySetMembers(LPCHARACTER ch);
		void 			PartyWarJoin(LPPARTY pParty, long lFromMapIndex, long MapIndex, int x, int y);
		
		/*Gm*/
		void			StartPartyWarEvent(LPCHARACTER ch, DWORD dwType, DWORD dwTime);
		void 			StartEvent(const std::string& event, DWORD type);
		DWORD 			GetEventType(const std::string& event);
		DWORD 			GetRemainingTime(const std::string& name);
		
	private:
		/*Leaders*/
		void			EnterPartyWarLeader(LPCHARACTER pkChar);
		void			RemovePartyWarLeader(LPCHARACTER pkChar);
		
		/*Members*/
		void			RemovePartyWarMember(LPCHARACTER pkChar);
		bool 			HasPartyWarLeader(LPCHARACTER pkChar);
		DWORD 			GetPartyWarMembersCount() { return m_map_partywarmember.size(); }
		
		void 			PartySetReward();
		
		/*Event*/
		bool			IsPartyWarWinner();
		
		/*Gm*/
		void 			StartTimer(const std::string& name, DWORD duration);

};