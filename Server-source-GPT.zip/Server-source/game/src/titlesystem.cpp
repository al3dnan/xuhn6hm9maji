#include "stdafx.h"

#ifdef __TITLE_SYSTEM_YUMA__
#include "desc_client.h"
#include "desc_manager.h"
#include "char.h"
#include "db.h"
#include "item.h"
#include "titlesystem.h"

CTitleSystem::CTitleSystem()
{
}

CTitleSystem::~CTitleSystem()
{
	m_stTitle = "";
	m_mapTitlesByID.clear();
}

void CTitleSystem::Initialize()
{
	// clear the map if it's not empty.
	if (!m_mapTitlesByID.empty())
		m_mapTitlesByID.clear();

	std::unique_ptr<SQLMsg> pMsg(DBManager::instance().DirectQuery("SELECT id, szTitle, szColorHEX FROM player.titlesystem"));

	if (pMsg->uiSQLErrno != 0 || pMsg->Get()->uiNumRows == 0)
		return;

	MYSQL_ROW row = NULL;
	while((row = mysql_fetch_row(pMsg->Get()->pSQLResult)))
	{
		char szTitle[TITLE_MAX_LEN + 1];
		DWORD dwColorID = strtoul(row[2], NULL, 0);
		TTitleTable table;

		str_to_number(table.dwID, row[0]);
		strlcpy(table.szTitle, row[1], sizeof(szTitle));
		table.dwColor = dwColorID;
		m_mapTitlesByID.insert(std::make_pair(table.dwID, table));
	}
}

void CTitleSystem::SetTitleString(const std::string& title)
{
	m_stTitle = title;
}

void CTitleSystem::UseTitleItem(bool bEquip, int iValue0)
{
	if (bEquip)
		SetTitleString(GetTitleFromDatabase(iValue0));
	else
		SetTitleString("");
}

#ifdef __COSTUMIZED_TITLE__
void CTitleSystem::UseCostumeTitleItem(LPCHARACTER pkChar, bool bEquip)
{
	if (bEquip)
		SetTitleString(pkChar->GetTitleName());
	else
		SetTitleString("");
}
#endif

DWORD CTitleSystem::GetColorFromDatabase(int iValue0) const
{
	const auto & it = m_mapTitlesByID.find(iValue0);
	if (it == m_mapTitlesByID.end())
		return 0;
	return it->second.dwColor;
}

std::string CTitleSystem::GetTitleFromDatabase(int iValue0) const
{
	const auto & it = m_mapTitlesByID.find(iValue0);
	if (it == m_mapTitlesByID.end())
		return "";
	return  it->second.szTitle;
}

std::pair<std::string, DWORD> CTitleSystem::GetTitleString(LPCHARACTER pkChar)
{
	if (!pkChar->IsPC())
		return std::make_pair("", 0);

	LPITEM pkTitleItem = pkChar->FindTitleItem();
	if (pkTitleItem == NULL)
		return std::make_pair("", 0);

#ifdef __COSTUMIZED_TITLE__
	if (pkTitleItem->GetVnum() == COSTUMIZED_TITLE_ITEM) {
		//pkChar->ChatPacket(CHAT_TYPE_INFO, "atoi : %d %s", atoi(pkChar->GetTitleColor()), pkChar->GetTitleColor());
		return std::make_pair(pkChar->GetTitleName(),  strtoul(pkChar->GetTitleColor(), NULL, 0));
	}
#endif

	int iTitleID = pkTitleItem->GetValue(0);
	std::string szTitle = GetTitleFromDatabase(iTitleID);

	return std::make_pair(szTitle, GetColorFromDatabase(iTitleID));
}
#endif