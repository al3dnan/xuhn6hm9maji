#pragma once

#include <string>

typedef struct STitleTable 
{
	DWORD dwID;
	char szTitle[TITLE_MAX_LEN + 1];
	DWORD dwColor;
} TTitleTable;

class CTitleSystem : public singleton<CTitleSystem>
{
	public:
		CTitleSystem();
		virtual ~CTitleSystem();

		void 							Initialize();

		std::pair<std::string, DWORD> 	GetTitleString(LPCHARACTER pkChar);
		void							UseTitleItem(bool bEquip, int iValue0);
#ifdef __COSTUMIZED_TITLE__
		void 							UseCostumeTitleItem(LPCHARACTER pkChar, bool bEquip);
#endif

	private:
		std::string m_stTitle;
		std::map<DWORD, TTitleTable> m_mapTitlesByID;

		DWORD			GetColorFromDatabase(int iValue0) const;
		std::string		GetTitleFromDatabase(int iValue0) const;

		void			SetTitleString(const std::string& title);
};
